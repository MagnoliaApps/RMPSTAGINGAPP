import React, { useState, useCallback, useEffect } from 'react';
import { Header } from '../components/Header';
import { ImageUploader } from '../components/ImageUploader';
import { PromptControls } from '../components/PromptControls';
import { ResultViewer } from '../components/ResultViewer';
import { StagedResult, StagingError, StyleTemplate } from '../types';
import { stageImageWithGemini, isImageSafeForStaging, isPromptSafe, getDesignInspirations, getRoomTypeSuggestions, getRefinementSuggestions } from '../services/geminiService';
import { Loader } from '../components/Loader';

const StagingDashboard: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<File | null>(null);
  const [originalImageBase64, setOriginalImageBase64] = useState<string | null>(null);
  const [history, setHistory] = useState<StagedResult[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isValidatingImage, setIsValidatingImage] = useState<boolean>(false);
  const [error, setError] = useState<StagingError | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [promptHistory, setPromptHistory] = useState<string[]>([]);
  const [loadingMessage, setLoadingMessage] = useState("Staging your vision... this may take a moment.");
  const [isStagingViewVisible, setIsStagingViewVisible] = useState(false);
  
  // State for AI suggestions
  const [inspirations, setInspirations] = useState<StyleTemplate[]>([]);
  const [isInspiring, setIsInspiring] = useState<boolean>(false);
  const [roomInspirations, setRoomInspirations] = useState<StyleTemplate[]>([]);
  const [isSuggestingForRoom, setIsSuggestingForRoom] = useState<boolean>(false);
  const [refinementSuggestions, setRefinementSuggestions] = useState<StyleTemplate[]>([]);
  const [isSuggestingRefinements, setIsSuggestingRefinements] = useState<boolean>(false);


  const currentStagedResult = historyIndex > -1 ? history[historyIndex] : null;

  const loadingMessages = [
    "Analyzing room layout...",
    "Selecting virtual furniture...",
    "Applying textures and lighting...",
    "Putting on the finishing touches...",
    "Finalizing the scene..."
  ];

  useEffect(() => {
    let interval: number | undefined;
    if (isLoading) {
        let index = 0;
        setLoadingMessage(loadingMessages[index]);
        interval = window.setInterval(() => {
            index = (index + 1) % loadingMessages.length;
            setLoadingMessage(loadingMessages[index]);
        }, 2500);
    }
    return () => {
        if (interval) {
            clearInterval(interval);
        }
    };
  }, [isLoading]);

  useEffect(() => {
    if (originalImageBase64) {
      const timer = setTimeout(() => setIsStagingViewVisible(true), 50);
      return () => clearTimeout(timer);
    } else {
      setIsStagingViewVisible(false);
    }
  }, [originalImageBase64]);


  const handleImageUpload = async (file: File, base64: string) => {
    setIsValidatingImage(true);
    setUploadError(null);
    setError(null);
    try {
        const isSafe = await isImageSafeForStaging(base64, file.type);
        if (!isSafe) {
            setUploadError('Validation Failed: The uploaded image is unsuitable. Please avoid photos containing explicit content, weapons, or portraits.');
            return;
        }
        setOriginalImage(file);
        setOriginalImageBase64(base64);
        setHistory([]);
        setHistoryIndex(-1);
        setError(null);
    } catch (err) {
        console.error("Image validation error:", err);
        setUploadError('An error occurred during image validation. Please try again.');
    } finally {
        setIsValidatingImage(false);
    }
  };
  
  const buildFinalPrompt = (prompt: string, negativePrompt: string): string => {
    let finalPrompt = prompt.trim();
    const negPrompt = negativePrompt.trim();
    
    if (negPrompt) {
        if (finalPrompt && !/[.!?]$/.test(finalPrompt)) {
            finalPrompt += '.';
        }
        finalPrompt += ` IMPORTANT: Do not include the following items or concepts: ${negPrompt}.`;
    }

    if (!finalPrompt) {
        return 'Slightly improve the image quality and composition. Do not change the room structure, walls, flooring, or any existing furniture.';
    }

    const structureChangeKeywords = ['wall', 'paint', 'floor', 'flooring', 'window', 'ceiling', 'color of the room'];
    const isRequestingStructureChange = structureChangeKeywords.some(keyword => finalPrompt.toLowerCase().includes(keyword));

    if (!isRequestingStructureChange) {
      if (finalPrompt && !/[.!?]$/.test(finalPrompt)) {
          finalPrompt += '.';
      }
      finalPrompt += " CRITICAL INSTRUCTION: You must preserve the room's existing architecture. Do not change the walls, windows, flooring, or ceiling. Only modify the furniture and decor.";
    }
    
    return finalPrompt;
  }
  
  const handleGeneration = async (sourceImage: string, mimeType: string, prompt: string, negativePrompt: string) => {
    setIsLoading(true);
    setError(null);
    setRefinementSuggestions([]); // Clear old refinement suggestions

    try {
        const combinedUserPrompt = `${prompt} ${negativePrompt}`;
        const isSafe = await isPromptSafe(combinedUserPrompt);
        if (!isSafe) {
            setError({ title: 'Inappropriate Content', message: 'Your prompt violates our safety guidelines. Please revise it and try again.' });
            setIsLoading(false);
            return;
        }

        const promptToSave = prompt.trim();
        if (promptToSave) {
            setPromptHistory(prev => [promptToSave, ...prev.filter(p => p !== promptToSave)].slice(0, 10));
        }

        const finalPrompt = buildFinalPrompt(prompt, negativePrompt);
        const result = await stageImageWithGemini(sourceImage, mimeType, finalPrompt);

        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push({ ...result, prompt: finalPrompt });
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
    } catch (err) {
        console.error(err);
        const action = historyIndex > -1 ? 'Refinement' : 'Generation';
        setError({ title: `${action} Failed`, message: `Our AI engine encountered an issue. Please try a different prompt or image.` });
    } finally {
        setIsLoading(false);
    }
  };

  const handleStageRequest = (prompt: string, negativePrompt: string) => {
    if (originalImage && originalImageBase64) {
        setRoomInspirations([]); // Clear room-specific suggestions after first staging
        handleGeneration(originalImageBase64, originalImage.type, prompt, negativePrompt);
    } else {
        setError({ title: 'No Image', message: 'Please upload an image before staging.' });
    }
  };

  const handleRefineRequest = (prompt: string, negativePrompt: string) => {
    if (currentStagedResult?.image) {
        const mimeTypeMatch = currentStagedResult.image.match(/data:(.*);base64,/);
        const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : 'image/png';
        handleGeneration(currentStagedResult.image, mimeType, prompt, negativePrompt);
    } else {
        setError({ title: 'No Staged Image', message: 'There is no staged image to refine.' });
    }
  };

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      setRefinementSuggestions([]);
      setHistoryIndex(historyIndex - 1);
    }
  }, [historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setRefinementSuggestions([]);
      setHistoryIndex(historyIndex + 1);
    }
  }, [historyIndex, history.length]);

  const handleReset = () => {
      setOriginalImage(null);
      setOriginalImageBase64(null);
      setHistory([]);
      setHistoryIndex(-1);
      setError(null);
      setUploadError(null);
      setIsLoading(false);
      setPromptHistory([]);
      setInspirations([]);
      setRoomInspirations([]);
      setRefinementSuggestions([]);
  }

  const handleInspireMe = useCallback(async () => {
    if (!originalImage || !originalImageBase64 || isInspiring) return;
    setIsInspiring(true);
    setError(null);
    try {
        const result = await getDesignInspirations(originalImageBase64, originalImage.type);
        setInspirations(result);
        setRoomInspirations([]);
    } catch (err) {
        console.error(err);
        setError({ title: 'Inspiration Failed', message: 'Our AI designer is taking a break. Please try again in a moment.' });
    } finally {
        setIsInspiring(false);
    }
  }, [originalImage, originalImageBase64, isInspiring]);

  const handleGetRoomInspirations = useCallback(async (roomType: string) => {
    if (!originalImage || !originalImageBase64 || isSuggestingForRoom) return;
    setIsSuggestingForRoom(true);
    setError(null);
    try {
        const result = await getRoomTypeSuggestions(originalImageBase64, originalImage.type, roomType);
        setRoomInspirations(result);
        setInspirations([]);
    } catch (err) {
        console.error(err);
        setError({ title: 'Suggestion Failed', message: 'Could not generate ideas for this room type. Please try again.' });
    } finally {
        setIsSuggestingForRoom(false);
    }
  }, [originalImage, originalImageBase64, isSuggestingForRoom]);

  const handleGetRefinementSuggestions = useCallback(async () => {
    if (!currentStagedResult || isSuggestingRefinements) return;
    setIsSuggestingRefinements(true);
    setError(null);
    try {
        const mimeTypeMatch = currentStagedResult.image.match(/data:(.*);base64,/);
        const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : 'image/png';
        const result = await getRefinementSuggestions(currentStagedResult.image, mimeType, currentStagedResult.prompt);
        setRefinementSuggestions(result);
    } catch (err) {
        console.error(err);
        setError({ title: 'Suggestion Failed', message: 'Could not generate refinement ideas. Please try again.' });
    } finally {
        setIsSuggestingRefinements(false);
    }
  }, [currentStagedResult, isSuggestingRefinements]);

  const handleEnhanceRequest = useCallback(async () => {
    if (!currentStagedResult?.image) {
      setError({ title: 'No Staged Image', message: 'There is no staged image to enhance.' });
      return;
    }

    setIsLoading(true);
    setError(null);
    
    try {
      const enhancePrompt = "Enhance the image quality, making it higher resolution with sharper details. Do not change the content, style, furniture, or layout of the room. Simply improve the visual fidelity of the existing image.";
      
      const mimeTypeMatch = currentStagedResult.image.match(/data:(.*);base64,/);
      const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : 'image/png';
      
      const result = await stageImageWithGemini(currentStagedResult.image, mimeType, enhancePrompt);
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push({ ...result, prompt: enhancePrompt });
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    } catch (err) {
      console.error(err);
      setError({ title: 'Enhancement Failed', message: 'Our AI engine encountered an issue while enhancing the image. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  }, [currentStagedResult, history, historyIndex]);

  const handleRegenerateRequest = useCallback(async () => {
    if (!currentStagedResult) {
        setError({ title: 'Cannot Regenerate', message: 'There is no image to regenerate.' });
        return;
    }

    const sourceImage = historyIndex === 0 ? originalImageBase64 : history[historyIndex - 1]?.image;
    const mimeTypeSource = historyIndex === 0 ? originalImage?.type : sourceImage?.match(/data:(.*);base64,/)?.[1];
    const promptToRegenerate = currentStagedResult.prompt;

    if (!sourceImage || !mimeTypeSource || !promptToRegenerate) {
        setError({ title: 'Cannot Regenerate', message: 'Missing data to regenerate this image.' });
        return;
    }

    setIsLoading(true);
    setError(null);
    setRefinementSuggestions([]);
    
    try {
        const result = await stageImageWithGemini(sourceImage, mimeTypeSource, promptToRegenerate);
        
        const newHistory = history.slice(0, historyIndex + 1); 
        newHistory.push({ ...result, prompt: promptToRegenerate });
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);

    } catch (err) {
        console.error(err);
        setError({ title: 'Regeneration Failed', message: 'Our AI engine encountered an issue. Please try again.' });
    } finally {
        setIsLoading(false);
    }
}, [currentStagedResult, history, historyIndex, originalImageBase64, originalImage]);


  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-800">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {!originalImageBase64 ? (
          <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="p-4 sm:p-8">
              <h2 className="text-2xl font-bold text-gray-700 mb-2">Virtual Staging Studio</h2>
              <p className="text-gray-500 mb-6">Upload a room photo, describe your vision, and let our AI bring it to life.</p>
              <ImageUploader onImageUpload={handleImageUpload} isLoading={isValidatingImage} uploadError={uploadError}/>
            </div>
          </div>
        ) : (
          <div className={`transition-opacity duration-500 ease-in-out ${isStagingViewVisible ? 'opacity-100' : 'opacity-0'}`}>
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
              {/* --- Left Column (Sticky Controls) --- */}
              <div className="lg:col-span-2 h-full">
                <div className="sticky top-8 bg-white rounded-2xl shadow-lg p-8">
                  <h2 className="text-2xl font-bold text-gray-700 mb-2">Staging Controls</h2>
                  <p className="text-gray-500 mb-6">Use the tools below to transform your image.</p>
                  <PromptControls 
                    onStageRequest={handleStageRequest} 
                    isLoading={isLoading} 
                    promptHistory={promptHistory}
                    onInspireMe={handleInspireMe}
                    isInspiring={isInspiring}
                    inspirations={inspirations}
                    onGetRoomInspirations={handleGetRoomInspirations}
                    isSuggestingForRoom={isSuggestingForRoom}
                    roomInspirations={roomInspirations}
                  />
                </div>
              </div>

              {/* --- Right Column (Image Display) --- */}
              <div className="lg:col-span-3">
                <div className="bg-white rounded-2xl shadow-lg overflow-hidden p-4 md:p-8 space-y-6">
                  {error && (
                    <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded" role="alert">
                      <p className="font-bold">{error.title}</p>
                      <p>{error.message}</p>
                    </div>
                  )}
                  {isLoading && (
                    <div className="flex flex-col items-center justify-center p-8 bg-gray-100 rounded-lg">
                        <Loader />
                        <p className="mt-4 text-lg font-semibold text-blue-700 animate-pulse">{loadingMessage}</p>
                        <p className="text-gray-500 mt-2">Our AI is re-imagining your space.</p>
                    </div>
                  )}
                  <ResultViewer 
                    originalImage={originalImageBase64} 
                    stagedResult={currentStagedResult} 
                    onReset={handleReset}
                    onRefine={handleRefineRequest}
                    onUndo={handleUndo}
                    onRedo={handleRedo}
                    canUndo={historyIndex > 0}
                    canRedo={historyIndex < history.length - 1}
                    onEnhance={handleEnhanceRequest}
                    onRegenerate={handleRegenerateRequest}
                    isLoading={isLoading}
                    promptHistory={promptHistory}
                    onGetRefinementSuggestions={handleGetRefinementSuggestions}
                    isSuggestingRefinements={isSuggestingRefinements}
                    refinementSuggestions={refinementSuggestions}
                  />
                </div>
              </div>
            </div>
          </div>
        )}
        <footer className="text-center mt-8 text-gray-400 text-sm">
          <p>Powered by RealMarketPulse. Images are AI-generated.</p>
        </footer>
      </main>
    </div>
  );
};

export default StagingDashboard;