import React, { useState, useEffect } from 'react';
import { HomeIcon } from '../components/icons/HomeIcon';
import { GoogleIcon } from '../components/icons/GoogleIcon';
import { AppleIcon } from '../components/icons/AppleIcon';
import { generateHeroImage } from '../services/geminiService';
import { Loader } from '../components/Loader';

interface SignUpPageProps {
  onSignUpSuccess: () => void;
}

const SignUpPage: React.FC<SignUpPageProps> = ({ onSignUpSuccess }) => {
  const [showcaseImageUrl, setShowcaseImageUrl] = useState<string | null>(null);
  const [isLoadingImage, setIsLoadingImage] = useState(true);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchShowcaseImage = async () => {
        setIsLoadingImage(true);
        try {
            // A vertical aspect ratio is better for this layout
            const imageBytes = await generateHeroImage('3:4');
            setShowcaseImageUrl(`data:image/jpeg;base64,${imageBytes}`);
        } catch (error) {
            console.error("Failed to load showcase image.", error);
        } finally {
            setIsLoadingImage(false);
        }
    };
    fetchShowcaseImage();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    // In a real app, you'd handle form validation and API calls here.
    // For this demo, we'll just proceed to the dashboard.
    setError(null);
    onSignUpSuccess();
  };

  return (
    <div className="min-h-screen bg-white font-sans flex">
      {/* Left side: Visual Showcase */}
      <div className="hidden lg:block relative w-1/2 bg-gray-900">
        <div className="absolute inset-0 flex items-center justify-center p-8">
           {isLoadingImage ? (
              <div className="text-center">
                  <Loader />
                  <p className="mt-4 text-sm text-gray-400">Generating inspiration...</p>
              </div>
            ) : showcaseImageUrl ? (
                <img 
                    src={showcaseImageUrl} 
                    alt="AI-staged room showcase" 
                    className="w-full h-full object-cover rounded-2xl shadow-2xl"
                />
            ) : (
                <div className="w-full h-full bg-gray-800 rounded-2xl flex items-center justify-center">
                    <p className="text-gray-500">Image failed to load</p>
                </div>
            )}
        </div>
        <div className="absolute bottom-8 left-8 right-8 p-6 bg-black/40 backdrop-blur-md rounded-xl">
            <h2 className="text-2xl font-bold text-white">"The easiest way to stage a home."</h2>
            <p className="text-gray-300 mt-2">- Happy Real Estate Agent</p>
        </div>
      </div>

      {/* Right side: Sign-up Form */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center items-center p-8 sm:p-12">
        <div className="w-full max-w-md">
            <a href="#" className="-m-1.5 p-1.5 flex items-center justify-center text-indigo-700 mb-8">
                <HomeIcon className="w-8 h-8 mr-2"/>
                <span className="text-2xl font-bold tracking-tight text-slate-900">PulseView-It</span>
            </a>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900 text-center">
                Create your account
            </h1>
            <p className="mt-3 text-slate-600 text-center">
                Start turning empty spaces into dream homes today.
            </p>

            <div className="mt-8 space-y-4">
                 <button className="w-full flex items-center justify-center gap-3 py-3 px-4 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors">
                    <GoogleIcon className="w-5 h-5" />
                    <span className="text-sm font-medium">Sign up with Google</span>
                 </button>
                 <button className="w-full flex items-center justify-center gap-3 py-3 px-4 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors">
                    <AppleIcon className="w-5 h-5" />
                    <span className="text-sm font-medium">Sign up with Apple</span>
                 </button>
            </div>
            
            <div className="my-6 flex items-center">
                <div className="flex-grow border-t border-slate-300"></div>
                <span className="mx-4 text-sm text-slate-500">OR</span>
                <div className="flex-grow border-t border-slate-300"></div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                    <label htmlFor="name" className="block text-sm font-medium text-slate-700">Full Name</label>
                    <input type="text" id="name" name="name" required className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"/>
                </div>
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-slate-700">Email Address</label>
                    <input type="email" id="email" name="email" required className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"/>
                </div>
                <div>
                    <label htmlFor="password" className="block text-sm font-medium text-slate-700">Password</label>
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        required 
                        value={password}
                        onChange={(e) => { setPassword(e.target.value); setError(null); }}
                        className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    />
                </div>
                <div>
                    <label htmlFor="confirm-password" className="block text-sm font-medium text-slate-700">Confirm Password</label>
                    <input 
                        type="password" 
                        id="confirm-password" 
                        name="confirm-password" 
                        required
                        value={confirmPassword}
                        onChange={(e) => { setConfirmPassword(e.target.value); setError(null); }}
                        className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    />
                    {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
                </div>
                 <div>
                    <label htmlFor="role" className="block text-sm font-medium text-slate-700">I am a...</label>
                    <select id="role" name="role" className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500">
                        <option>Real Estate Agent</option>
                        <option>Interior Designer</option>
                        <option>Property Developer</option>
                        <option>Homeowner / Seller</option>
                        <option>Other</option>
                    </select>
                </div>
                <div>
                    <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-transform transform hover:scale-105">
                        Create Account
                    </button>
                </div>
            </form>

            <p className="mt-6 text-center text-xs text-slate-500">
                By creating an account, you agree to our{' '}
                <a href="#" className="font-medium text-indigo-600 hover:text-indigo-500">
                    Terms of Service
                </a>{' '}
                and{' '}
                <a href="#" className="font-medium text-indigo-600 hover:text-indigo-500">
                    Privacy Policy
                </a>.
            </p>

            <p className="mt-6 text-center text-sm text-slate-600">
                Already have an account?{' '}
                <button onClick={onSignUpSuccess} className="font-medium text-indigo-600 hover:text-indigo-500">
                    Log in
                </button>
            </p>
        </div>
      </div>
    </div>
  );
};

export default SignUpPage;