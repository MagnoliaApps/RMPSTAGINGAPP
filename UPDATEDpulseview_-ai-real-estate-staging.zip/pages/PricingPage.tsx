import React, { useState } from 'react';
import { HomeIcon } from '../components/icons/HomeIcon';
import { CheckCircleIcon } from '../components/icons/CheckCircleIcon';

interface PricingPageProps {
  onNavigateToSignUp: () => void;
}

const plans = [
    {
        name: 'Basic',
        id: 'basic',
        price: { monthly: 0, yearly: 0 },
        description: 'Perfect for trying out the basics of AI staging.',
        features: [
            '4 Staging Credits / Year',
            'Standard Image Quality',
            'Watermarked Downloads',
            'Access to Basic Styles',
        ],
        cta: 'Get Started',
        highlight: false,
    },
    {
        name: 'Pro',
        id: 'pro',
        price: { monthly: 39.99, yearly: 384 },
        description: 'For professionals who need high-quality results, fast.',
        features: [
            '50 AI Staging Credits / Month',
            'HD Image Quality Downloads',
            'No Watermarks',
            'Access to Premium Styles',
            'Priority Support',
        ],
        cta: 'Choose Pro',
        highlight: true,
    },
    {
        name: 'Business',
        id: 'business',
        price: { monthly: 99, yearly: 950 },
        description: 'For teams and agencies with high-volume needs.',
        features: [
            'Unlimited AI Staging Credits',
            '4K Image Quality Downloads',
            'Team Collaboration Tools',
            'Dedicated Account Manager',
            'Advanced Analytics',
        ],
        cta: 'Contact Sales',
        highlight: false,
    }
];

const PricingPage: React.FC<PricingPageProps> = ({ onNavigateToSignUp }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
       <header className="bg-white shadow-sm">
        <div className="container mx-auto flex items-center justify-between p-6 lg:px-8">
            <div className="flex">
                <a href="#" className="-m-1.5 p-1.5 flex items-center text-indigo-700">
                    <HomeIcon className="w-8 h-8 mr-2"/>
                    <span className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">PulseView-It</span>
                </a>
            </div>
        </div>
       </header>

       <main className="py-24 sm:py-32">
        <div className="container mx-auto px-6 lg:px-8">
            <div className="mx-auto max-w-4xl text-center">
                <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
                    Choose the Plan That's Right For You
                </h1>
                <p className="mt-6 text-lg leading-8 text-slate-600">
                    Simple, transparent pricing. No hidden fees. Cancel anytime.
                </p>
            </div>

            <div className="mt-16 flex justify-center">
                <div className="relative flex items-center rounded-full bg-slate-200 p-1">
                    <button
                        onClick={() => setBillingCycle('monthly')}
                        className={`relative w-28 rounded-full py-2 text-sm font-semibold transition-colors ${billingCycle === 'monthly' ? 'text-white' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                        Monthly
                    </button>
                    <button
                        onClick={() => setBillingCycle('yearly')}
                        className={`relative w-28 rounded-full py-2 text-sm font-semibold transition-colors ${billingCycle === 'yearly' ? 'text-white' : 'text-slate-500 hover:text-slate-700'}`}
                    >
                        Yearly
                    </button>
                    <div
                        className={`absolute inset-y-1 left-1 h-10 w-28 rounded-full bg-indigo-600 shadow-md transition-transform duration-300 ease-in-out ${billingCycle === 'yearly' ? 'translate-x-full' : ''}`}
                        aria-hidden="true"
                    ></div>
                     <span className="absolute -top-4 -right-20 transform -rotate-12 bg-cyan-300 text-cyan-800 text-xs font-bold px-3 py-1 rounded-full shadow-md">
                        Save 20%
                    </span>
                </div>
            </div>

            <div className="isolate mx-auto mt-16 grid max-w-md grid-cols-1 gap-8 lg:mx-0 lg:max-w-none lg:grid-cols-3">
                {plans.map((plan) => (
                    <div
                        key={plan.id}
                        className={`relative rounded-3xl p-8 ring-1 xl:p-10 ${plan.highlight ? 'bg-slate-900 ring-0' : 'bg-white ring-slate-200'}`}
                    >
                        {plan.highlight && (
                            <span className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-600 px-3 py-1 text-xs font-semibold tracking-wide text-white">
                                Most Popular
                            </span>
                        )}
                        <h3 className={`text-lg font-semibold leading-8 ${plan.highlight ? 'text-white' : 'text-slate-900'}`}>{plan.name}</h3>
                        <p className={`mt-4 text-sm leading-6 ${plan.highlight ? 'text-slate-300' : 'text-slate-600'}`}>{plan.description}</p>
                        <p className="mt-6 flex items-baseline gap-x-1">
                            {plan.id === 'business' && (
                                <span className={`text-xl font-normal ${plan.highlight ? 'text-slate-300' : 'text-slate-600'}`}>Starting at&nbsp;</span>
                            )}
                            <span className={`text-4xl font-bold tracking-tight ${plan.highlight ? 'text-white' : 'text-slate-900'}`}>
                                {plan.price.monthly === 0 ? 'Free' : `$${billingCycle === 'monthly' ? plan.price.monthly : Math.round(plan.price.yearly / 12)}`}
                            </span>
                             {plan.price.monthly > 0 && (
                                <span className={`text-sm font-semibold leading-6 ${plan.highlight ? 'text-slate-300' : 'text-slate-600'}`}>/month</span>
                             )}
                        </p>
                        {billingCycle === 'yearly' && plan.price.yearly > 0 && (
                             <p className={`mt-1 text-xs ${plan.highlight ? 'text-slate-400' : 'text-slate-500'}`}>Billed as ${plan.price.yearly} per year</p>
                        )}
                        <button
                            onClick={plan.id !== 'business' ? onNavigateToSignUp : undefined}
                            aria-describedby={plan.id}
                            className={`mt-6 block w-full rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 transition-all transform hover:scale-105 ${
                                plan.highlight 
                                ? 'bg-white text-slate-900 hover:bg-slate-100 focus-visible:outline-white' 
                                : plan.id === 'business'
                                ? 'bg-slate-800 text-white hover:bg-slate-700 focus-visible:outline-slate-800'
                                : 'bg-indigo-600 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline-indigo-600'
                            }`}
                        >
                           {plan.cta}
                        </button>
                        <ul role="list" className={`mt-8 space-y-3 text-sm leading-6 xl:mt-10 ${plan.highlight ? 'text-slate-300' : 'text-slate-600'}`}>
                            {plan.features.map((feature) => (
                                <li key={feature} className="flex gap-x-3">
                                    <CheckCircleIcon className={`h-6 w-6 flex-none ${plan.highlight ? 'text-white' : 'text-indigo-600'}`} aria-hidden="true" />
                                    {feature}
                                </li>
                            ))}
                        </ul>
                    </div>
                ))}
            </div>
        </div>
       </main>

        <footer className="bg-slate-50">
            <div className="container mx-auto mt-8 border-t border-slate-200 py-8 text-center">
                <p className="text-base text-slate-500">&copy; {new Date().getFullYear()} PulseView-It by RealMarketPulse. All rights reserved.</p>
            </div>
        </footer>
    </div>
  )
}

export default PricingPage;