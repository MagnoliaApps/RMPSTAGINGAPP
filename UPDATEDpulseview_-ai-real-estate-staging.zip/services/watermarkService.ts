
export const applyWatermark = (base64Image: string): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    // Allow cross-origin images for canvas tainting
    img.crossOrigin = 'anonymous';
    img.src = base64Image;

    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        return reject(new Error('Could not get canvas context'));
      }

      // 1. Draw the original image
      ctx.drawImage(img, 0, 0);

      // 2. Set watermark properties
      const watermarkText = 'Staged by PulseView-It';
      // Responsive font size, with a minimum and maximum
      const fontSize = Math.max(12, Math.min(Math.round(img.naturalWidth / 40), 48)); 
      ctx.font = `bold ${fontSize}px "Helvetica Neue", Arial, sans-serif`;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.6)'; // Semi-transparent white
      ctx.textAlign = 'right';
      ctx.textBaseline = 'bottom';
      
      // Add a subtle shadow for better readability on various backgrounds
      ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
      ctx.shadowBlur = Math.max(2, fontSize / 8);
      ctx.shadowOffsetX = 1;
      ctx.shadowOffsetY = 1;

      // 3. Draw the watermark text
      const padding = Math.max(10, Math.round(img.naturalWidth / 80));
      ctx.fillText(watermarkText, canvas.width - padding, canvas.height - padding);

      // 4. Get the new image as a PNG data URL
      resolve(canvas.toDataURL('image/png'));
    };

    img.onerror = () => {
      reject(new Error('Failed to load image for watermarking.'));
    };
  });
};
