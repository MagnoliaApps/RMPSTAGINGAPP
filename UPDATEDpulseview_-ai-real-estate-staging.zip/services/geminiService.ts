import { GoogleGenAI, Modality, GenerateContentResponse, Type } from "@google/genai";
import { StagedResult, StyleTemplate } from '../types';

const MODEL_NAME = 'gemini-2.5-flash-image-preview';
const FAST_MODEL = 'gemini-2.5-flash';
const IMAGE_GEN_MODEL = 'imagen-4.0-generate-001';

function getApiKey(): string {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new Error('API_KEY environment variable not set.');
    }
    return apiKey;
}

const ai = new GoogleGenAI({ apiKey: getApiKey() });

const suggestionSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            name: {
                type: Type.STRING,
                description: 'A very short, catchy name for the idea (e.g., "Add a Rug", "Modern Style").',
            },
            prompt: {
                type: Type.STRING,
                description: 'A detailed prompt that can be used to generate or modify an image based on the suggestion.',
            },
        },
        required: ['name', 'prompt'],
    },
};

export const isImageSafeForStaging = async (imageBase64: string, mimeType: string): Promise<boolean> => {
    if (!imageBase64.startsWith('data:')) {
        throw new Error('Invalid base64 string. Must be a data URL.');
    }
    const base64Data = imageBase64.split(',')[1];

    try {
        const response = await ai.models.generateContent({
            model: FAST_MODEL,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Data,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: "Analyze the image. Does it contain nudity, weapons, or is it primarily a headshot/portrait of a person? Answer with only 'yes' if it contains any of these, or 'no' if it is safe for a general audience and suitable for a property staging application.",
                    },
                ],
            },
        });

        const resultText = response.text.trim().toLowerCase();
        // The prompt asks to return 'no' if it is safe.
        return resultText.includes('no');
    } catch (error) {
        console.error("Error during image validation:", error);
        // Fail safely - if validation fails, assume it's not a valid image.
        return false;
    }
};

export const isPromptSafe = async (prompt: string): Promise<boolean> => {
    if (!prompt.trim()) {
        return true; // An empty prompt is safe.
    }
    try {
        const response = await ai.models.generateContent({
            model: FAST_MODEL,
            contents: prompt,
            config: {
                systemInstruction: "You are a content moderator. Analyze the user's prompt. If it contains any vulgarity, profanity, hate speech, explicit content, or other inappropriate material, respond with only the word 'unsafe'. Otherwise, respond with only the word 'safe'.",
            }
        });
        
        const resultText = response.text.trim().toLowerCase();
        return resultText.includes('safe');
    } catch (error) {
        console.error("Error during prompt validation:", error);
        // Fail safely - if validation fails, assume it's unsafe.
        return false;
    }
};


export const stageImageWithGemini = async (imageBase64: string, mimeType: string, prompt: string): Promise<StagedResult> => {
    if (!imageBase64.startsWith('data:')) {
        throw new Error('Invalid base64 string. Must be a data URL.');
    }

    const base64Data = imageBase64.split(',')[1];
    if (!base64Data) {
        throw new Error('Could not extract base64 data from string.');
    }

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: MODEL_NAME,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Data,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: prompt,
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });
        
        let newImageBase64: string | null = null;
        let responseText = "AI analysis complete.";

        if (response.candidates && response.candidates[0] && response.candidates[0].content && response.candidates[0].content.parts) {
            for (const part of response.candidates[0].content.parts) {
                if (part.inlineData) {
                    newImageBase64 = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
                } else if (part.text) {
                    responseText = part.text;
                }
            }
        }

        if (!newImageBase64) {
            throw new Error("The AI service did not return an image. This may be due to a safety policy violation or an invalid prompt.");
        }

        return {
            image: newImageBase64,
            text: responseText,
            prompt: prompt,
        };
    } catch (error) {
        console.error("Error calling the AI image generation service:", error);
        throw new Error("Failed to stage image with the AI service.");
    }
};

export const getDesignInspirations = async (imageBase64: string, mimeType: string): Promise<StyleTemplate[]> => {
    if (!imageBase64.startsWith('data:')) {
        throw new Error('Invalid base64 string. Must be a data URL.');
    }
    const base64Data = imageBase64.split(',')[1];

    try {
        const response = await ai.models.generateContent({
            model: FAST_MODEL,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Data,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: "Analyze this room and suggest 3-4 creative interior design styles that would suit the space. Provide a name and a detailed prompt for each.",
                    },
                ],
            },
            config: {
                responseMimeType: "application/json",
                responseSchema: suggestionSchema,
                systemInstruction: "You are an expert interior designer. Analyze the user's image of a room and provide 3-4 distinct and creative design style suggestions that would suit the space. For each suggestion, provide a name for the style and a detailed descriptive prompt that another AI can use to virtually stage the room with that style.",
            },
        });

        const jsonStr = response.text.trim();
        const inspirations: StyleTemplate[] = JSON.parse(jsonStr);
        
        if (!Array.isArray(inspirations) || inspirations.some(item => typeof item.name !== 'string' || typeof item.prompt !== 'string')) {
            throw new Error("Invalid JSON structure received from AI.");
        }

        return inspirations;
    } catch (error) {
        console.error("Error during design inspiration generation:", error);
        throw new Error("Failed to get design inspirations from the AI service.");
    }
};

export const getRoomTypeSuggestions = async (imageBase64: string, mimeType: string, roomType: string): Promise<StyleTemplate[]> => {
    const base64Data = imageBase64.split(',')[1];
    try {
        const response = await ai.models.generateContent({
            model: FAST_MODEL,
            contents: {
                parts: [
                    { inlineData: { data: base64Data, mimeType: mimeType } },
                    { text: `Analyze this image, which is a ${roomType}, and suggest 3 distinct interior design styles that would be a great fit. For each style, provide a name and a detailed prompt.` }
                ]
            },
            config: {
                responseMimeType: "application/json",
                responseSchema: suggestionSchema,
                systemInstruction: `You are an expert interior designer specializing in ${roomType} designs. Provide creative and suitable style suggestions.`
            }
        });
        const jsonStr = response.text.trim();
        return JSON.parse(jsonStr);
    } catch (error) {
        console.error("Error getting room type suggestions:", error);
        throw new Error("Failed to get room-specific design suggestions.");
    }
};

export const getRefinementSuggestions = async (stagedImageBase64: string, mimeType: string, originalPrompt: string): Promise<StyleTemplate[]> => {
    const base64Data = stagedImageBase64.split(',')[1];
    try {
        const response = await ai.models.generateContent({
            model: FAST_MODEL,
            contents: {
                parts: [
                    { inlineData: { data: base64Data, mimeType: mimeType } },
                    { text: `This image was generated from a prompt that included: "${originalPrompt}". Based on this image, suggest 3-4 small, specific, and creative refinements. Each suggestion should be an actionable prompt to add, remove, or change something minor. Examples: "Add a large potted plant in the corner," "Change the throw pillows on the sofa to a deep blue color," "Place a stack of books on the coffee table."` }
                ]
            },
            config: {
                responseMimeType: "application/json",
                responseSchema: suggestionSchema,
                systemInstruction: "You are an AI design assistant. Your goal is to suggest small, iterative improvements to an existing AI-generated image. The suggestions should be concise and ready to be used as prompts."
            }
        });
        const jsonStr = response.text.trim();
        return JSON.parse(jsonStr);
    } catch (error) {
        console.error("Error getting refinement suggestions:", error);
        throw new Error("Failed to get refinement suggestions.");
    }
};

export const generateHeroImage = async (aspectRatio: '16:9' | '3:4' = '16:9'): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: IMAGE_GEN_MODEL,
            prompt: `A photorealistic image showing a living room that seamlessly transitions from a beautifully staged modern interior on one side to an empty, neutral room on the other side, with soft, dramatic lighting. The image should be visually striking and high-quality.`,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: aspectRatio,
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
            return base64ImageBytes;
        } else {
            throw new Error("The AI service did not return an image for the hero section.");
        }
    } catch (error) {
        console.error("Error calling the AI image generation service for hero image:", error);
        throw new Error("Failed to generate hero image with the AI service.");
    }
};