import React, { useState } from 'react';
import LandingPage from './pages/LandingPage';
import StagingDashboard from './pages/StagingDashboard';
import SignUpPage from './pages/SignUpPage';
import PricingPage from './pages/PricingPage';

type Page = 'landing' | 'pricing' | 'signup' | 'dashboard';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('landing');

  const renderPage = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onNavigateToPricing={() => setCurrentPage('pricing')} />;
      case 'pricing':
        return <PricingPage onNavigateToSignUp={() => setCurrentPage('signup')} />;
      case 'signup':
        return <SignUpPage onSignUpSuccess={() => setCurrentPage('dashboard')} />;
      case 'dashboard':
        return <StagingDashboard />;
      default:
        return <LandingPage onNavigateToPricing={() => setCurrentPage('pricing')} />;
    }
  };

  return <>{renderPage()}</>;
};

export default App;