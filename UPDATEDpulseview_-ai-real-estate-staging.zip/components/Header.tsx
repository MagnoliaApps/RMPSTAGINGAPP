
import React from 'react';
import { HomeIcon } from './icons/HomeIcon';

export const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex items-center">
        <div className="flex items-center text-blue-700">
          <HomeIcon className="w-8 h-8 mr-2"/>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight">PulseView-It</h1>
        </div>
      </div>
    </header>
  );
};
