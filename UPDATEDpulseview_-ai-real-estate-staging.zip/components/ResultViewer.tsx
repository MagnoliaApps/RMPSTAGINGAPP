import React, { useState, useEffect } from 'react';
import { StagedResult, StyleTemplate } from '../types';
import { DownloadIcon } from './icons/DownloadIcon';
import { RedoIcon } from './icons/RedoIcon';
import { ImageComparisonSlider } from './ImageComparisonSlider';
import { PromptHistory } from './PromptHistory';
import { SparklesIcon } from './icons/SparklesIcon';
import { ZoomInIcon } from './icons/ZoomInIcon';
import { ImageZoomModal } from './ImageZoomModal';
import { DownloadModal } from './DownloadModal';
import { UndoIcon } from './icons/UndoIcon';
import { RegenerateIcon } from './icons/RegenerateIcon';
import { Tooltip } from './Tooltip';


interface ResultViewerProps {
  originalImage: string | null;
  stagedResult: StagedResult | null;
  onReset: () => void;
  onRefine: (prompt: string, negativePrompt: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onEnhance: () => void;
  onRegenerate: () => void;
  isLoading: boolean;
  promptHistory: string[];
  onGetRefinementSuggestions: () => void;
  isSuggestingRefinements: boolean;
  refinementSuggestions: StyleTemplate[];
}

export const ResultViewer: React.FC<ResultViewerProps> = ({ 
  originalImage, stagedResult, onReset, onRefine, onUndo, onRedo, 
  canUndo, canRedo, onEnhance, onRegenerate, isLoading, promptHistory,
  onGetRefinementSuggestions, isSuggestingRefinements, refinementSuggestions
}) => {
  const [refinePrompt, setRefinePrompt] = useState('');
  const [negativeRefinePrompt, setNegativeRefinePrompt] = useState('');
  const [isResultVisible, setIsResultVisible] = useState(false);
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [feedbackState, setFeedbackState] = useState<'idle' | 'prompting' | 'submitted'>('idle');
  const [feedbackText, setFeedbackText] = useState('');

  useEffect(() => {
    let timer: number;
    if (stagedResult) {
      // Use a short timeout to allow the DOM to update before adding the visible class,
      // ensuring the transition is triggered.
      timer = window.setTimeout(() => setIsResultVisible(true), 100);
      setFeedbackState('idle');
      setFeedbackText('');
    } else {
      setIsResultVisible(false);
    }
    return () => {
      if(timer) window.clearTimeout(timer);
    };
  }, [stagedResult]);


  if (!originalImage) return null;

  const handleRefineSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((refinePrompt.trim() || negativeRefinePrompt.trim()) && !isLoading) {
      onRefine(refinePrompt, negativeRefinePrompt);
      setRefinePrompt('');
      setNegativeRefinePrompt('');
    }
  };
  
  const handleFeedbackSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      console.log(`User feedback: Result was not helpful. Reason: ${feedbackText}`);
      setFeedbackState('submitted');
  }

  const handleOpenDownloadModal = () => {
    if (!stagedResult || !stagedResult.image) return;
    setIsDownloadModalOpen(true);
  };

  return (
    <div className="mt-4">
      {stagedResult ? (
        <div className={`transition-opacity duration-700 ease-in-out ${isResultVisible ? 'opacity-100' : 'opacity-0'}`}>
          <ImageComparisonSlider
            beforeImage={originalImage}
            afterImage={stagedResult.image}
            onZoomBefore={() => setZoomedImage(originalImage)}
            onZoomAfter={() => setZoomedImage(stagedResult.image)}
          />
          <div className="mt-6 flex flex-wrap justify-center sm:justify-end items-center gap-3">
              <Tooltip text="Improve image resolution and sharpness using AI. This does not change the content.">
                <button
                    onClick={onEnhance}
                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-purple-700 bg-purple-100 border border-purple-200 rounded-md shadow-sm hover:bg-purple-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-gray-200 disabled:cursor-not-allowed transition-all duration-200 transform hover:-translate-y-0.5"
                    disabled={isLoading}
                    aria-label="Enhance image quality"
                >
                    <SparklesIcon className="w-5 h-5 mr-2" />
                    Enhance Quality
                </button>
              </Tooltip>
              <Tooltip text="Go back to the previous version of the image.">
                <button
                    onClick={onUndo}
                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-200 transform hover:-translate-y-0.5"
                    disabled={isLoading || !canUndo}
                    aria-label="Undo last change"
                >
                    <UndoIcon className="w-5 h-5 mr-2" />
                    Undo
                </button>
              </Tooltip>
              <Tooltip text="Restore the change you just undid.">
                <button
                    onClick={onRedo}
                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-200 transform hover:-translate-y-0.5"
                    disabled={isLoading || !canRedo}
                    aria-label="Redo last change"
                >
                    <RedoIcon className="w-5 h-5 mr-2" />
                    Redo
                </button>
              </Tooltip>
              <Tooltip text="Generate a new variation using the same prompt that created this image.">
                <button
                    onClick={onRegenerate}
                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-200 transform hover:-translate-y-0.5"
                    disabled={isLoading}
                    aria-label="Try generating this image again"
                >
                    <RegenerateIcon className="w-5 h-5 mr-2" />
                    Try Again
                </button>
              </Tooltip>
              <Tooltip text="Open the download options for the final image.">
                <button
                    onClick={handleOpenDownloadModal}
                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 transition-all duration-200 transform hover:-translate-y-0.5"
                    disabled={isLoading}
                    aria-label="Save staged image"
                >
                    <DownloadIcon className="w-5 h-5 mr-2" />
                    Save Image
                </button>
              </Tooltip>
          </div>
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-semibold text-blue-800">AI Notes:</h4>
              <p className="text-sm text-blue-700 mt-1">{stagedResult.text}</p>
          </div>
          <form onSubmit={handleRefineSubmit} className="mt-6 space-y-4">
              <h3 className="text-lg font-semibold text-gray-700">Refine Your Design</h3>
              <p className="text-sm text-gray-500">Describe another change you'd like to make to the "After" image.</p>
              
              <Tooltip text="Let the AI suggest small, creative changes for this image.">
                <button
                    type="button"
                    onClick={onGetRefinementSuggestions}
                    disabled={isLoading || isSuggestingRefinements}
                    className="w-full flex items-center justify-center px-4 py-2 text-sm font-medium text-purple-700 bg-purple-100 border border-purple-200 rounded-md shadow-sm hover:bg-purple-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed transition-all"
                >
                    {isSuggestingRefinements ? (
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-purple-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    ) : (
                        <SparklesIcon className="w-4 h-4 mr-2" />
                    )}
                    {isSuggestingRefinements ? 'Getting Ideas...' : 'Suggest Refinements'}
                </button>
              </Tooltip>

              {refinementSuggestions.length > 0 && (
                <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-3">✨ Refinement Ideas</h4>
                    <div className="flex flex-wrap gap-2">
                    {refinementSuggestions.map((template) => (
                        <button
                        key={template.name}
                        type="button"
                        onClick={() => setRefinePrompt(template.prompt)}
                        disabled={isLoading}
                        className="px-4 py-2 text-sm font-medium text-purple-700 bg-purple-200 rounded-full hover:bg-purple-300 disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-200 hover:shadow-sm"
                        >
                        {template.name}
                        </button>
                    ))}
                    </div>
                </div>
              )}

              <div>
                <label htmlFor="refine-prompt" className="block text-sm font-medium text-gray-700 mb-1">Your Changes</label>
                <textarea
                    id="refine-prompt"
                    value={refinePrompt}
                    onChange={(e) => setRefinePrompt(e.target.value)}
                    placeholder='e.g., "Make the sofa red" or "Add a floor lamp in the corner."'
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow"
                    rows={2}
                    disabled={isLoading}
                />
                <PromptHistory history={promptHistory} onSelect={setRefinePrompt} isLoading={isLoading} />
              </div>
              <div>
                <label htmlFor="refine-negative-prompt" className="block text-sm font-medium text-gray-700 mb-1">Exclude Items</label>
                <textarea
                    id="refine-negative-prompt"
                    value={negativeRefinePrompt}
                    onChange={(e) => setNegativeRefinePrompt(e.target.value)}
                    placeholder='e.g., "no more chairs", "avoid patterns"'
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-400 focus:border-red-400 transition-shadow"
                    rows={1}
                    disabled={isLoading}
                />
              </div>
              <Tooltip text="Apply the changes described above to the current staged image.">
                <button
                    type="submit"
                    disabled={isLoading || (!refinePrompt.trim() && !negativeRefinePrompt.trim())}
                    className="w-full flex items-center justify-center px-6 py-3 text-base font-medium text-white bg-green-600 border border-transparent rounded-md shadow-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg active:translate-y-0"
                >
                    {isLoading ? 'Refining...' : 'Refine It!'}
                </button>
              </Tooltip>
          </form>

          {/* Feedback Section */}
          <div className="mt-6 border-t border-gray-200 pt-6">
            {feedbackState === 'idle' && (
              <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg flex items-center justify-between flex-wrap gap-4">
                <p className="font-semibold text-gray-700">Was this result helpful?</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setFeedbackState('submitted');
                      console.log("User feedback: Result was helpful.");
                    }}
                    className="px-6 py-2 text-sm font-medium text-green-700 bg-green-100 rounded-full hover:bg-green-200 transition-colors"
                    aria-label="Confirm the result was helpful"
                  >
                    Yes
                  </button>
                  <button
                    onClick={() => setFeedbackState('prompting')}
                    className="px-6 py-2 text-sm font-medium text-red-700 bg-red-100 rounded-full hover:bg-red-200 transition-colors"
                    aria-label="Confirm the result was not helpful"
                  >
                    No
                  </button>
                </div>
              </div>
            )}

            {feedbackState === 'prompting' && (
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <form onSubmit={handleFeedbackSubmit}>
                  <label htmlFor="feedback-text" className="block text-sm font-medium text-gray-700 mb-2">
                    We're sorry it wasn't helpful. What could we do better?
                  </label>
                  <textarea
                    id="feedback-text"
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                    placeholder="e.g., The furniture style was wrong, it didn't remove the object I asked for..."
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow"
                    rows={3}
                  />
                  <button
                    type="submit"
                    className="mt-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
                    disabled={!feedbackText.trim()}
                  >
                    Submit Feedback
                  </button>
                </form>
              </div>
            )}

            {feedbackState === 'submitted' && (
              <div className="text-center p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="font-semibold text-green-700">Thanks for your feedback!</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        !isLoading && (
          <>
            <div className="relative bg-gray-100 p-2 rounded-lg shadow-inner group">
              <h4 className="text-center font-semibold text-gray-600 mb-2">Before</h4>
              <img src={originalImage} alt="Before" className="rounded-md w-full object-contain" />
              <button
                onClick={() => setZoomedImage(originalImage)}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 p-4 rounded-full bg-black/40 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 focus:opacity-100 focus:outline-none"
                aria-label="Zoom in on before image"
              >
                <ZoomInIcon className="w-8 h-8" />
              </button>
            </div>
             <div className="mt-6 flex flex-col items-center justify-center text-center p-8 bg-blue-50/50 border-2 border-dashed border-blue-200 rounded-lg">
                <SparklesIcon className="w-12 h-12 text-blue-500 mb-4" />
                <h3 className="text-xl font-bold text-gray-700">Your vision comes to life here!</h3>
                <p className="mt-2 text-gray-500 max-w-sm">Use the controls to describe the changes you want to see, then click "Stage It!" to witness the transformation.</p>
            </div>
          </>
        )
      )}
       <div className="mt-8 border-t border-gray-200 pt-6 text-center">
            <Tooltip text="Clear the current session and upload a new image." position="top">
              <button
                  onClick={onReset}
                  className="px-6 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-full hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors"
                  disabled={isLoading}
              >
                  Start Over with a New Image
              </button>
            </Tooltip>
        </div>
        {zoomedImage && (
          <ImageZoomModal imageUrl={zoomedImage} onClose={() => setZoomedImage(null)} />
        )}
        {isDownloadModalOpen && stagedResult && (
          <DownloadModal 
            imageUrl={stagedResult.image} 
            onClose={() => setIsDownloadModalOpen(false)} 
          />
        )}
    </div>
  );
};