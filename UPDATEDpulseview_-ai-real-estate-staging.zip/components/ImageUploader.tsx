
import React, { useState, useCallback } from 'react';
import { UploadIcon } from './icons/UploadIcon';
import { Loader } from './Loader';

interface ImageUploaderProps {
  onImageUpload: (file: File, base64: string) => void;
  isLoading: boolean;
  uploadError: string | null;
}

const MAX_FILE_SIZE_MB = 10;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
const SUPPORTED_FORMATS = ['image/jpeg', 'image/png'];

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, isLoading, uploadError }) => {
  const [localError, setLocalError] = useState<string | null>(null);

  const handleFileChange = useCallback((files: FileList | null) => {
    setLocalError(null);
    if (!files || files.length === 0) {
      return;
    }
    const file = files[0];

    if (!SUPPORTED_FORMATS.includes(file.type)) {
      setLocalError(`Invalid file type. Please upload a JPEG or PNG image.`);
      return;
    }

    if (file.size > MAX_FILE_SIZE_BYTES) {
      setLocalError(`File is too large. Maximum size is ${MAX_FILE_SIZE_MB}MB.`);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      onImageUpload(file, reader.result as string);
    };
    reader.onerror = () => {
      setLocalError("Failed to read the file.");
    };
    reader.readAsDataURL(file);
  }, [onImageUpload]);

  const onDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
  };
  
  const onDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    if (isLoading) return;
    handleFileChange(e.dataTransfer.files);
  };
  
  const finalError = uploadError || localError;

  return (
    <div className="flex items-center justify-center w-full">
      <label 
        htmlFor="dropzone-file" 
        className={`flex flex-col items-center justify-center w-full h-56 sm:h-64 border-2 border-dashed rounded-lg transition-colors ${isLoading ? 'bg-gray-100' : 'cursor-pointer bg-gray-50 hover:bg-gray-100'} ${finalError ? 'border-red-400' : 'border-gray-300'}`}
        onDragOver={onDragOver}
        onDrop={onDrop}
      >
        {isLoading ? (
          <div className="flex flex-col items-center justify-center text-center">
            <Loader />
            <p className="mt-4 font-semibold text-blue-700">Validating image...</p>
            <p className="text-sm text-gray-500">Please wait while we check the image for suitability.</p>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <UploadIcon className="w-10 h-10 mb-3 text-gray-400" />
            <p className="mb-2 text-sm text-gray-500"><span className="font-semibold">Click to upload</span> or drag and drop</p>
            <p className="text-xs text-gray-500">PNG or JPG (MAX. {MAX_FILE_SIZE_MB}MB)</p>
          </div>
        )}
        <input id="dropzone-file" type="file" className="hidden" accept="image/png, image/jpeg" onChange={(e) => handleFileChange(e.target.files)} disabled={isLoading} />
        {finalError && <p className="mt-2 text-xs text-red-600">{finalError}</p>}
      </label>
    </div> 
  );
};
