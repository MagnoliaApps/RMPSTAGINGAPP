
export interface StagedResult {
  image: string; // base64 string
  text: string;
  prompt: string;
}

export interface StagingError {
  title: string;
  message: string;
}

export interface StyleTemplate {
  name: string;
  prompt: string;
}