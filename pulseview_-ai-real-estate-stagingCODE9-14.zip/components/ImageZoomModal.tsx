
import React, { useState, useRef, useEffect, useCallback } from 'react';

interface ImageZoomModalProps {
  imageUrl: string;
  onClose: () => void;
}

const MIN_SCALE = 1;
const MAX_SCALE = 8;

export const ImageZoomModal: React.FC<ImageZoomModalProps> = ({ imageUrl, onClose }) => {
  const [scale, setScale] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [startPoint, setStartPoint] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    }
  }, [onClose]);

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [handleKeyDown]);
  
  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    const delta = e.deltaY * -0.005;
    const newScale = Math.min(Math.max(MIN_SCALE, scale + delta), MAX_SCALE);

    if (containerRef.current && imageRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        
        // Mouse position relative to the container
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        // Calculate the point on the image that the mouse is pointing to
        const imageX = (mouseX - pan.x) / scale;
        const imageY = (mouseY - pan.y) / scale;

        const newPanX = mouseX - imageX * newScale;
        const newPanY = mouseY - imageY * newScale;
        
        setPan({ x: newPanX, y: newPanY });
    }
    
    setScale(newScale);
  };
  
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (scale > 1) {
        setIsPanning(true);
        setStartPoint({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isPanning) return;
    e.preventDefault();
    setPan({ x: e.clientX - startPoint.x, y: e.clientY - startPoint.y });
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  // Reset pan when zoomed all the way out
  useEffect(() => {
      if (scale <= MIN_SCALE) {
          setPan({ x: 0, y: 0 });
      }
  }, [scale]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Image zoom view"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 backdrop-blur-sm"
      onClick={onClose}
    >
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-white text-4xl font-bold z-50 hover:text-gray-300 transition-colors"
        aria-label="Close"
      >
        &times;
      </button>
      <div className="absolute top-4 left-4 text-white/80 bg-black/30 px-2 py-1 rounded text-sm">
        Use mouse wheel to zoom, click and drag to pan.
      </div>
      <div
        ref={containerRef}
        className="relative w-full h-full overflow-hidden"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onClick={(e) => e.stopPropagation()} // Prevent modal from closing when clicking on the image area
      >
        <img
          ref={imageRef}
          src={imageUrl}
          alt="Zoomed view"
          className="absolute top-0 left-0 w-full h-full object-contain max-w-none max-h-none"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${scale})`,
            cursor: scale > 1 ? (isPanning ? 'grabbing' : 'grab') : 'default',
            transition: isPanning ? 'none' : 'transform 0.1s ease-out',
          }}
        />
      </div>
    </div>
  );
};
