
import React, { useState, useCallback } from 'react';
import { UploadIcon } from '../icons/UploadIcon';

interface TrialUploaderProps {
  onImageUpload: (file: File, base64: string) => void;
}

const MAX_FILE_SIZE_MB = 10;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
const SUPPORTED_FORMATS = ['image/jpeg', 'image/png'];

export const TrialUploader: React.FC<TrialUploaderProps> = ({ onImageUpload }) => {
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = useCallback((files: FileList | null) => {
    setError(null);
    if (!files || files.length === 0) return;
    
    const file = files[0];

    if (!SUPPORTED_FORMATS.includes(file.type)) {
      setError(`Invalid file type. Please upload a JPEG or PNG.`);
      return;
    }

    if (file.size > MAX_FILE_SIZE_BYTES) {
      setError(`File is too large. Max size is ${MAX_FILE_SIZE_MB}MB.`);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      onImageUpload(file, reader.result as string);
    };
    reader.onerror = () => {
      setError("Failed to read the file.");
    };
    reader.readAsDataURL(file);
  }, [onImageUpload]);

  const onDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
  };
  
  const onDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    handleFileChange(e.dataTransfer.files);
  };

  return (
    <div className="flex items-center justify-center w-full">
      <label 
        htmlFor="trial-dropzone-file" 
        className={`flex flex-col items-center justify-center w-full h-56 sm:h-64 border-2 border-dashed rounded-lg transition-colors cursor-pointer bg-white/10 hover:bg-white/20 ${error ? 'border-red-400' : 'border-white/30'}`}
        onDragOver={onDragOver}
        onDrop={onDrop}
      >
        <div className="flex flex-col items-center justify-center pt-5 pb-6 text-center">
            <UploadIcon className="w-10 h-10 mb-3 text-indigo-100" />
            <p className="mb-2 text-sm text-white"><span className="font-semibold">Click to upload</span> or drag and drop</p>
            <p className="text-xs text-indigo-100">PNG or JPG (MAX. {MAX_FILE_SIZE_MB}MB)</p>
        </div>
        <input id="trial-dropzone-file" type="file" className="hidden" accept="image/png, image/jpeg" onChange={(e) => handleFileChange(e.target.files)} />
        {error && <p className="mt-2 text-xs text-red-300">{error}</p>}
      </label>
    </div> 
  );
};
