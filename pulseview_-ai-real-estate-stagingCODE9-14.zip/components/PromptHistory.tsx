import React from 'react';

interface PromptHistoryProps {
  history: string[];
  onSelect: (prompt: string) => void;
  isLoading: boolean;
}

export const PromptHistory: React.FC<PromptHistoryProps> = ({ history, onSelect, isLoading }) => {
  if (history.length === 0) {
    return null;
  }

  const handleSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (e.target.value) {
      onSelect(e.target.value);
      // Reset select to placeholder
      e.target.value = "";
    }
  };

  return (
    <div className="mt-4">
      <label htmlFor="prompt-history" className="block text-sm font-medium text-gray-700 mb-1">
        Or use a recent prompt
      </label>
      <select 
        id="prompt-history"
        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow bg-white"
        onChange={handleSelect}
        defaultValue=""
        disabled={isLoading}
        aria-label="Select a recent prompt"
      >
        <option value="" disabled>Select from history...</option>
        {history.map((p, i) => (
          <option key={`${i}-${p}`} value={p}>
            {p.length > 70 ? `${p.substring(0, 70)}...` : p}
          </option>
        ))}
      </select>
    </div>
  );
};
