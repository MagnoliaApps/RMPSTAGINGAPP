import React, { useState, useRef, useEffect, useCallback } from 'react';
import { LandingHeader } from '../components/landing/LandingHeader';
import { TrialUploader } from '../components/landing/TrialUploader';
import { SignUpModal } from '../components/landing/SignUpModal';
import { HomeIcon } from '../components/icons/HomeIcon';
import { BuildingIcon } from '../components/icons/BuildingIcon';
import { ImageIcon } from '../components/icons/ImageIcon';
import { PaintBrushIcon } from '../components/icons/PaintBrushIcon';
import { CheckIcon } from '../components/icons/CheckIcon';
import { MagicWandIcon } from '../components/icons/MagicWandIcon';
import { MouseIcon } from '../components/icons/MouseIcon';
import { SofaIcon } from '../components/icons/SofaIcon';
import { XCircleIcon } from '../components/icons/XCircleIcon';
import { generateHeroImage } from '../services/geminiService';


interface LandingPageProps {
  onSignUp: () => void;
}

type UserType = 'agents' | 'builders' | 'homeowners' | 'designers';

const userBenefits = {
  agents: {
    title: "For Real Estate Agents",
    icon: HomeIcon,
    points: [
      "Win more listings with stunning, virtually staged photos.",
      "Sell properties faster by helping buyers visualize their future home.",
      "Save thousands on physical staging costs and logistics.",
      "Enhance listing photos to look professional and appealing."
    ],
  },
  builders: {
    title: "For Property Developers",
    icon: BuildingIcon,
    points: [
      "Showcase projects before they're built with realistic renderings.",
      "Place a finished home model onto an empty plot of land.",
      "Help clients visualize floor plans and material finishes.",
      "Accelerate off-plan sales with compelling marketing visuals."
    ],
  },
  homeowners: {
    title: "For Homeowners & Sellers",
    icon: HomeIcon,
    points: [
      "Increase your property's sale price by showcasing its full potential.",
      "Declutter and re-style your current home for listings without moving a thing.",
      "Visualize renovations or new furniture in your own space.",
      "Create your dream home by experimenting with different styles."
    ],
  },
  designers: {
    title: "For Interior Designers",
    icon: PaintBrushIcon,
    points: [
      "Quickly create multiple design mockups for clients.",
      "Present your vision with photorealistic AI-generated images.",
      "Experiment with bold styles and furniture layouts instantly.",
      "Streamline your design process and impress your clients."
    ],
  }
};

const HeroPlaceholder = () => (
    <div className="relative w-full h-full bg-white rounded-md shadow-lg flex ring-1 ring-slate-200">
      {/* Before part */}
      <div className="w-1/2 h-full bg-slate-100 p-4 rounded-l-md">
        <div className="w-3/4 h-8 bg-slate-200 rounded animate-pulse"></div>
        <div className="w-1/2 h-4 bg-slate-200 rounded mt-4 animate-pulse" style={{ animationDelay: '0.2s' }}></div>
      </div>
      {/* After part */}
      <div className="w-1/2 h-full bg-gradient-to-br from-cyan-50 to-indigo-100 p-4 rounded-r-md">
        <div className="w-3/4 h-8 bg-gradient-to-r from-cyan-400 to-indigo-400 rounded shadow animate-pulse"></div>
        <div className="w-1/2 h-4 bg-indigo-200 rounded mt-4 animate-pulse" style={{ animationDelay: '0.2s' }}></div>
        <div className="w-1/4 h-10 bg-cyan-300 rounded absolute bottom-4 right-4 shadow-lg animate-pulse" style={{ animationDelay: '0.4s' }}></div>
      </div>
      {/* Slider handle */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 h-full w-1.5 bg-white cursor-ew-resize">
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 left-1/2 w-8 h-8 rounded-full bg-white shadow-md ring-2 ring-indigo-500 flex items-center justify-center">
          <svg className="w-5 h-5 text-indigo-600 rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 9l4-4 4 4m0 6l-4 4-4-4"></path></svg>
        </div>
      </div>
    </div>
);


const LandingPage: React.FC<LandingPageProps> = ({ onSignUp }) => {
  const [showSignUpModal, setShowSignUpModal] = useState(false);
  const [trialImage, setTrialImage] = useState<string | null>(null);
  const [activeUserType, setActiveUserType] = useState<UserType>('agents');
  const [heroImageUrl, setHeroImageUrl] = useState<string | null>(null);
  const [isHeroLoading, setIsHeroLoading] = useState<boolean>(true);
  
  const tabsContainerRef = useRef<HTMLDivElement>(null);
  const [indicatorStyle, setIndicatorStyle] = useState({ left: 0, width: 0 });
  const userTypes = Object.keys(userBenefits) as UserType[];

  useEffect(() => {
    const fetchHeroImage = async () => {
        setIsHeroLoading(true);
        try {
            const imageBytes = await generateHeroImage();
            setHeroImageUrl(`data:image/jpeg;base64,${imageBytes}`);
        } catch (error) {
            console.error("Failed to load hero image, using fallback.", error);
            setHeroImageUrl(null); // Ensure fallback is shown on error
        } finally {
            setIsHeroLoading(false);
        }
    };
    fetchHeroImage();
  }, []);
  
  const updateIndicator = useCallback(() => {
    const container = tabsContainerRef.current;
    if (!container) return;

    const activeTab = container.querySelector(`button[data-type="${activeUserType}"]`) as HTMLButtonElement;
    if (activeTab) {
        setIndicatorStyle({
            left: activeTab.offsetLeft,
            width: activeTab.offsetWidth,
        });
    }
  }, [activeUserType]);

  useEffect(() => {
    updateIndicator();
    window.addEventListener('resize', updateIndicator);
    return () => window.removeEventListener('resize', updateIndicator);
  }, [updateIndicator]);


  const handleTrialUpload = (file: File, base64: string) => {
    setTrialImage(base64);
    setShowSignUpModal(true);
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-800">
      <LandingHeader onSignUp={onSignUp} />
      
      {/* Hero Section */}
      <main>
        <div className="relative isolate pt-14">
           <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80" aria-hidden="true">
            <div className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#a7f3d0] to-[#67e8f9] opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]" style={{clipPath: 'polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)'}}></div>
          </div>
          <div className="py-24 sm:py-32">
            <div className="container mx-auto px-6 lg:px-8">
              <div className="mx-auto max-w-2xl text-center">
                <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
                  Transform Any Space in Seconds with AI
                </h1>
                <p className="mt-6 text-lg leading-8 text-slate-600">
                  From empty rooms to stunning listings, PulseView-It is the ultimate virtual staging and visualization tool for real estate professionals, builders, and homeowners.
                </p>
                <div className="mt-10 flex items-center justify-center gap-x-6">
                  <button
                    onClick={onSignUp}
                    className="rounded-md bg-indigo-600 px-5 py-3 text-lg font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 transition-all transform hover:scale-105"
                  >
                    Get Started for Free
                  </button>
                </div>
              </div>
              <div className="mt-16 flow-root sm:mt-24">
                <div className="-m-2 rounded-xl bg-slate-900/5 p-2 ring-1 ring-inset ring-slate-900/10 lg:-m-4 lg:rounded-2xl lg:p-4">
                    <div className="relative w-full aspect-[16/9] bg-slate-200 rounded-md shadow-lg flex items-center justify-center ring-1 ring-slate-200">
                        {isHeroLoading ? (
                            <div className="text-center">
                                <svg className="animate-spin h-10 w-10 text-indigo-600 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                <p className="mt-2 text-sm text-slate-600">Generating hero image...</p>
                            </div>
                        ) : heroImageUrl ? (
                            <div className="relative w-full h-full">
                                <img src={heroImageUrl} alt="AI generated hero image of a living room transitioning from staged to empty" className="w-full h-full object-cover rounded-md"/>
                                {/* Static Slider handle overlay to emphasize the before/after transition */}
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 h-full w-1 bg-white/60 pointer-events-none">
                                    <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 left-1/2 w-10 h-10 rounded-full bg-white/90 shadow-md ring-2 ring-indigo-500 flex items-center justify-center backdrop-blur-sm">
                                    <svg className="w-6 h-6 text-indigo-600 rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 9l4-4 4 4m0 6l-4 4-4-4"></path></svg>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <HeroPlaceholder />
                        )}
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div id="features" className="bg-slate-50 py-24 sm:py-32">
          <div className="container mx-auto px-6 lg:px-8">
            <div className="mx-auto max-w-2xl lg:text-center">
              <h2 className="text-base font-semibold leading-7 text-indigo-600">Everything You Need</h2>
              <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">The Future of Property Visualization</p>
              <p className="mt-6 text-lg leading-8 text-slate-600">
                Go beyond traditional staging. Our powerful AI tools allow you to not just furnish a space, but completely reimagine it.
              </p>
            </div>
            <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
              <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-2 lg:gap-y-16">
                <div className="relative pl-16">
                  <dt className="text-base font-semibold leading-7 text-slate-900">
                    <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600">
                      <HomeIcon className="h-6 w-6 text-white" />
                    </div>
                    Virtual Staging & Restyling
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-slate-600">Turn empty rooms into beautifully furnished homes. Declutter, redesign, and edit existing listing photos to perfection with simple text prompts.</dd>
                </div>
                <div className="relative pl-16">
                  <dt className="text-base font-semibold leading-7 text-slate-900">
                    <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600">
                      <BuildingIcon className="h-6 w-6 text-white" />
                    </div>
                    Builder's Vision
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-slate-600">Visualize new constructions before breaking ground. Our AI can render a complete home mockup on an empty plot of land, helping sell your vision.</dd>
                </div>
                <div className="relative pl-16">
                  <dt className="text-base font-semibold leading-7 text-slate-900">
                    <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600">
                      <ImageIcon className="h-6 w-6 text-white" />
                    </div>
                    AI Photo Enhancement
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-slate-600">Instantly upgrade your photos. Enhance image quality, improve lighting, and increase resolution to create professional, eye-catching listings.</dd>
                </div>
                 <div className="relative pl-16">
                  <dt className="text-base font-semibold leading-7 text-slate-900">
                    <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600">
                      <PaintBrushIcon className="h-6 w-6 text-white" />
                    </div>
                    Limitless Design Styles
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-slate-600">From Modern Minimalist to Boho Chic, apply dozens of pre-designed templates or describe any style imaginable to match your client's taste.</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
        
        {/* Comparison Section */}
        <div id="compare" className="bg-white py-24 sm:py-32">
          <div className="container mx-auto px-6 lg:px-8">
            <div className="mx-auto max-w-2xl lg:text-center">
              <h2 className="text-base font-semibold leading-7 text-indigo-600">The PulseView-It Advantage</h2>
              <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">Finally, Staging on Your Terms</p>
              <p className="mt-6 text-lg leading-8 text-slate-600">
                Stop waiting and overpaying. See how our AI-powered platform stacks up against traditional methods.
              </p>
            </div>
            <div className="mx-auto mt-16 grid max-w-lg grid-cols-1 items-start gap-8 lg:max-w-none lg:grid-cols-3">
              {/* Column 1: Traditional Virtual Staging */}
              <div className="flex flex-col rounded-2xl border border-slate-200 p-8 h-full">
                <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-slate-100">
                        <MouseIcon className="h-7 w-7 text-slate-600" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900">Traditional Virtual Staging</h3>
                </div>
                <p className="text-slate-500 mt-4 text-sm">Manual editing by a designer using software like Photoshop.</p>
                <ul className="mt-6 space-y-4 text-sm">
                  <li className="flex items-start"><XCircleIcon className="h-5 w-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Cost:</span> High, often $50-$200+ per photo</div></li>
                  <li className="flex items-start"><XCircleIcon className="h-5 w-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Speed:</span> Slow, 1-3 day turnaround per revision</div></li>
                  <li className="flex items-start"><XCircleIcon className="h-5 w-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Revisions:</span> Limited & slow back-and-forth</div></li>
                  <li className="flex items-start"><XCircleIcon className="h-5 w-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Scope:</span> Limited to adding pre-made 3D furniture</div></li>
                </ul>
              </div>

              {/* Column 2: PulseView-It AI (Highlighted) */}
              <div className="relative flex flex-col rounded-2xl bg-slate-50 p-8 shadow-2xl ring-2 ring-indigo-600">
                <p className="absolute top-0 -translate-y-1/2 self-center rounded-full bg-indigo-600 px-3 py-1 text-xs font-semibold tracking-wide text-white">Most Popular</p>
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-indigo-100">
                      <MagicWandIcon className="h-7 w-7 text-indigo-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">PulseView-It AI</h3>
                </div>
                <p className="text-slate-500 mt-4 text-sm">Instant, intelligent staging powered by our advanced AI engine.</p>
                <ul className="mt-6 space-y-4 text-sm">
                  <li className="flex items-start"><CheckIcon className="h-5 w-5 text-teal-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Cost:</span> Affordable, included in simple plans</div></li>
                  <li className="flex items-start"><CheckIcon className="h-5 w-5 text-teal-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Speed:</span> Instant, results in seconds</div></li>
                  <li className="flex items-start"><CheckIcon className="h-5 w-5 text-teal-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Revisions:</span> Unlimited & instant, tweak endlessly</div></li>
                  <li className="flex items-start"><CheckIcon className="h-5 w-5 text-teal-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Scope:</span> Limitless; restyle, repaint, rebuild, & enhance</div></li>
                </ul>
              </div>

              {/* Column 3: Physical Staging */}
              <div className="flex flex-col rounded-2xl border border-slate-200 p-8 h-full">
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-slate-100">
                      <SofaIcon className="h-7 w-7 text-slate-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">Physical Staging</h3>
                </div>
                <p className="text-slate-500 mt-4 text-sm">Renting and arranging physical furniture in the property.</p>
                 <ul className="mt-6 space-y-4 text-sm">
                  <li className="flex items-start"><XCircleIcon className="h-5 w-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Cost:</span> Very High, thousands per month</div></li>
                  <li className="flex items-start"><XCircleIcon className="h-5 w-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Speed:</span> Very Slow, weeks to plan and execute</div></li>
                  <li className="flex items-start"><XCircleIcon className="h-5 w-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Revisions:</span> Costly & difficult</div></li>
                  <li className="flex items-start"><XCircleIcon className="h-5 w-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" /><div><span className="font-semibold text-slate-700">Scope:</span> Very limited by furniture inventory</div></li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* For Whom Section */}
        <div id="use-cases" className="bg-slate-50 py-24 sm:py-32">
          <div className="container mx-auto px-6 lg:px-8">
            <div className="mx-auto max-w-2xl lg:text-center">
               <h2 className="text-base font-semibold leading-7 text-indigo-600">Tailored For Your Success</h2>
               <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">A Powerful Tool for Every Professional</p>
            </div>
             <div className="mx-auto mt-16 max-w-4xl">
              <div className="w-full">
                <div className="border-b border-gray-200">
                  <nav ref={tabsContainerRef} className="relative -mb-px flex justify-start sm:justify-center space-x-4 sm:space-x-8 overflow-x-auto pb-1" aria-label="Tabs">
                    {userTypes.map((key) => (
                      <button
                        key={key}
                        data-type={key}
                        onClick={() => setActiveUserType(key)}
                        className={`${
                          activeUserType === key
                            ? 'text-indigo-600'
                            : 'text-slate-500 hover:text-slate-700'
                        } whitespace-nowrap py-4 px-1 font-medium text-sm transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-indigo-500 rounded-sm`}
                      >
                        {userBenefits[key].title}
                      </button>
                    ))}
                    <div
                        className="absolute bottom-0 h-0.5 bg-indigo-500 transition-all duration-300 ease-out"
                        style={indicatorStyle}
                    />
                  </nav>
                </div>
              </div>

              <div className="mt-12 relative h-64 sm:h-56">
                <div className="relative w-full h-full overflow-hidden">
                    {userTypes.map((key) => {
                        const isActive = activeUserType === key;
                        const activeIndex = userTypes.indexOf(activeUserType);
                        const currentIndex = userTypes.indexOf(key);
                        const position = currentIndex - activeIndex;

                        return (
                        <div
                            key={key}
                            className="absolute top-0 left-0 w-full h-full p-1 transition-all duration-500 ease-in-out"
                            style={{
                                transform: `translateX(${position * 100}%)`,
                                opacity: isActive ? 1 : 0,
                                transitionProperty: 'transform, opacity'
                            }}
                            aria-hidden={!isActive}
                        >
                            <div className="bg-white rounded-xl p-8 shadow-inner ring-1 ring-slate-200 h-full flex flex-col justify-center">
                              <ul role="list" className="space-y-4">
                                  {userBenefits[key].points.map((point, pIndex) => (
                                  <li key={pIndex} className="flex items-start">
                                      <div className="flex-shrink-0 pt-0.5">
                                      <CheckIcon className="h-6 w-6 text-teal-500" />
                                      </div>
                                      <p className="ml-3 text-base text-slate-700">{point}</p>
                                  </li>
                                  ))}
                              </ul>
                            </div>
                        </div>
                        );
                    })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Trial Section */}
        <div className="bg-white py-24 sm:py-32">
          <div className="container mx-auto px-6 lg:px-8">
            <div className="relative isolate overflow-hidden bg-gradient-to-r from-indigo-600 to-cyan-500 px-6 pt-16 shadow-2xl rounded-2xl sm:px-16 md:pt-24 lg:flex lg:gap-x-20 lg:px-24 lg:pt-0">
              <div className="mx-auto max-w-md text-center lg:mx-0 lg:flex-auto lg:py-32 lg:text-left">
                <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Ready to see the magic?</h2>
                <p className="mt-6 text-lg leading-8 text-indigo-100">Upload a photo to try it out. See how easy it is to transform your property listings and designs.</p>
              </div>
              <div className="relative mt-16 h-80 lg:mt-8">
                <div className="w-full max-w-sm mx-auto lg:mr-0 lg:max-w-lg flex items-center justify-center h-full">
                  <TrialUploader onImageUpload={handleTrialUpload} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
       <footer className="bg-white">
        <div className="container mx-auto py-12 px-6 lg:px-8">
           <div className="flex justify-center text-indigo-600">
             <HomeIcon className="w-8 h-8"/>
          </div>
          <div className="mt-8 border-t border-slate-200 pt-8 text-center">
            <p className="text-base text-slate-500">&copy; {new Date().getFullYear()} PulseView-It by RealMarketPulse. All rights reserved.</p>
          </div>
        </div>
      </footer>
      
      {showSignUpModal && trialImage && (
        <SignUpModal 
          imageUrl={trialImage} 
          onClose={() => setShowSignUpModal(false)}
          onSignUp={onSignUp}
        />
      )}
    </div>
  );
};

export default LandingPage;