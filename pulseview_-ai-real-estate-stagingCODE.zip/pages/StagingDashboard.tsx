
import React, { useState, useCallback, useEffect } from 'react';
import { Header } from '../components/Header';
import { ImageUploader } from '../components/ImageUploader';
import { PromptControls } from '../components/PromptControls';
import { ResultViewer } from '../components/ResultViewer';
import { StagedResult, StagingError, StyleTemplate } from '../types';
import { stageImageWithGemini, isImageSafeForStaging, isPromptSafe, getDesignInspirations } from '../services/geminiService';
import { Loader } from '../components/Loader';

type LastAction = {
  type: 'stage' | 'refine';
  prompt: string;
  negativePrompt: string;
};

const StagingDashboard: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<File | null>(null);
  const [originalImageBase64, setOriginalImageBase64] = useState<string | null>(null);
  const [stagedResult, setStagedResult] = useState<StagedResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isValidatingImage, setIsValidatingImage] = useState<boolean>(false);
  const [error, setError] = useState<StagingError | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [lastAction, setLastAction] = useState<LastAction | null>(null);
  const [promptHistory, setPromptHistory] = useState<string[]>([]);
  const [loadingMessage, setLoadingMessage] = useState("Staging your vision... this may take a moment.");
  const [isStagingViewVisible, setIsStagingViewVisible] = useState(false);
  const [inspirations, setInspirations] = useState<StyleTemplate[]>([]);
  const [isInspiring, setIsInspiring] = useState<boolean>(false);

  const loadingMessages = [
    "Analyzing room layout...",
    "Selecting virtual furniture...",
    "Applying textures and lighting...",
    "Putting on the finishing touches...",
    "Finalizing the scene..."
  ];

  useEffect(() => {
    let interval: number | undefined;
    if (isLoading) {
        let index = 0;
        setLoadingMessage(loadingMessages[index]);
        interval = window.setInterval(() => {
            index = (index + 1) % loadingMessages.length;
            setLoadingMessage(loadingMessages[index]);
        }, 2500);
    }
    return () => {
        if (interval) {
            clearInterval(interval);
        }
    };
  }, [isLoading]);

  useEffect(() => {
    if (originalImageBase64) {
      const timer = setTimeout(() => setIsStagingViewVisible(true), 50);
      return () => clearTimeout(timer);
    } else {
      setIsStagingViewVisible(false);
    }
  }, [originalImageBase64]);


  const handleImageUpload = async (file: File, base64: string) => {
    setIsValidatingImage(true);
    setUploadError(null);
    setError(null);
    try {
        const isSafe = await isImageSafeForStaging(base64, file.type);
        if (!isSafe) {
            setUploadError('Validation Failed: The uploaded image is unsuitable. Please avoid photos containing explicit content, weapons, or portraits.');
            return;
        }
        setOriginalImage(file);
        setOriginalImageBase64(base64);
        setStagedResult(null);
        setError(null);
        setLastAction(null);
    } catch (err) {
        console.error("Image validation error:", err);
        setUploadError('An error occurred during image validation. Please try again.');
    } finally {
        setIsValidatingImage(false);
    }
  };
  
  const buildFinalPrompt = (prompt: string, negativePrompt: string): string => {
    let finalPrompt = prompt.trim();
    const negPrompt = negativePrompt.trim();
    
    if (negPrompt) {
        if (finalPrompt && !/[.!?]$/.test(finalPrompt)) {
            finalPrompt += '.';
        }
        finalPrompt += ` IMPORTANT: Do not include the following items or concepts: ${negPrompt}.`;
    }

    if (!finalPrompt) {
        return 'Slightly improve the image quality and composition. Do not change the room structure, walls, flooring, or any existing furniture.';
    }

    const structureChangeKeywords = ['wall', 'paint', 'floor', 'flooring', 'window', 'ceiling', 'color of the room'];
    const isRequestingStructureChange = structureChangeKeywords.some(keyword => finalPrompt.toLowerCase().includes(keyword));

    if (!isRequestingStructureChange) {
      if (finalPrompt && !/[.!?]$/.test(finalPrompt)) {
          finalPrompt += '.';
      }
      finalPrompt += " CRITICAL INSTRUCTION: You must preserve the room's existing architecture. Do not change the walls, windows, flooring, or ceiling. Only modify the furniture and decor.";
    }
    
    return finalPrompt;
  }

  const handleStageRequest = useCallback(async (prompt: string, negativePrompt: string) => {
    if (!originalImage || !originalImageBase64) {
      setError({ title: 'No Image', message: 'Please upload an image before staging.' });
      return;
    }

    setIsLoading(true);
    setError(null);
    setStagedResult(null);

    try {
      const combinedUserPrompt = `${prompt} ${negativePrompt}`;
      const isSafe = await isPromptSafe(combinedUserPrompt);
      if (!isSafe) {
        setError({ title: 'Inappropriate Content', message: 'Your prompt violates our safety guidelines. Please revise it and try again.' });
        setIsLoading(false);
        return;
      }
        
      const promptToSave = prompt.trim();
      if (promptToSave) {
        setPromptHistory(prev => [promptToSave, ...prev.filter(p => p !== promptToSave)].slice(0, 10));
      }

      setLastAction({ type: 'stage', prompt, negativePrompt });
      const finalPrompt = buildFinalPrompt(prompt, negativePrompt);
      const result = await stageImageWithGemini(originalImageBase64, originalImage.type, finalPrompt);
      setStagedResult(result);
    } catch (err) {
      console.error(err);
      setError({ title: 'Generation Failed', message: 'Our AI engine encountered an issue. Please try a different prompt or image.' });
    } finally {
      setIsLoading(false);
    }
  }, [originalImage, originalImageBase64]);

  const handleRefineRequest = useCallback(async (prompt: string, negativePrompt: string) => {
    if (!stagedResult?.image) {
      setError({ title: 'No Staged Image', message: 'There is no staged image to refine.' });
      return;
    }

    setIsLoading(true);
    setError(null);
    
    try {
      const combinedUserPrompt = `${prompt} ${negativePrompt}`;
      const isSafe = await isPromptSafe(combinedUserPrompt);
      if (!isSafe) {
        setError({ title: 'Inappropriate Content', message: 'Your prompt violates our safety guidelines. Please revise it and try again.' });
        setIsLoading(false);
        return;
      }
      
      const promptToSave = prompt.trim();
      if (promptToSave) {
        setPromptHistory(prev => [promptToSave, ...prev.filter(p => p !== promptToSave)].slice(0, 10));
      }
      
      setLastAction({ type: 'refine', prompt, negativePrompt });
      const finalPrompt = buildFinalPrompt(prompt, negativePrompt);
      
      const mimeTypeMatch = stagedResult.image.match(/data:(.*);base64,/);
      const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : 'image/png';
      
      const result = await stageImageWithGemini(stagedResult.image, mimeType, finalPrompt);
      setStagedResult(result);
    } catch (err) {
      console.error(err);
      setError({ title: 'Refinement Failed', message: 'Our AI engine encountered an issue while refining the image. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  }, [stagedResult]);
  
  const handleRedo = useCallback(async () => {
      if (!lastAction || isLoading) return;

      setIsLoading(true);
      setError(null);
      
      const isRefining = lastAction.type === 'refine';
      const sourceImage = isRefining ? stagedResult?.image : originalImageBase64;
      
      let sourceMimeType: string | undefined;
      if (isRefining) {
          sourceMimeType = stagedResult?.image?.match(/data:(.*);base64,/)?.[1];
      } else {
          sourceMimeType = originalImage?.type;
      }
      
      if (!sourceImage || !sourceMimeType) {
        setError({ title: 'Redo Failed', message: 'Could not find the source image to redo the action.' });
        setIsLoading(false);
        return;
      }
      
      setStagedResult(null);

      const finalPrompt = buildFinalPrompt(lastAction.prompt, lastAction.negativePrompt);
      
      try {
        const result = await stageImageWithGemini(sourceImage, sourceMimeType, finalPrompt);
        setStagedResult(result);
      } catch (err) {
        console.error(err);
        setError({ title: 'Redo Failed', message: 'Our AI engine encountered an issue trying to regenerate the image. Please try again.' });
      } finally {
        setIsLoading(false);
      }
  }, [lastAction, isLoading, originalImage, originalImageBase64, stagedResult]);

  const handleReset = () => {
      setOriginalImage(null);
      setOriginalImageBase64(null);
      setStagedResult(null);
      setError(null);
      setUploadError(null);
      setIsLoading(false);
      setLastAction(null);
      setPromptHistory([]);
      setInspirations([]);
  }

  const handleInspireMe = useCallback(async () => {
    if (!originalImage || !originalImageBase64 || isInspiring) return;

    setIsInspiring(true);
    setError(null);

    try {
        const result = await getDesignInspirations(originalImageBase64, originalImage.type);
        setInspirations(result);
    } catch (err) {
        console.error(err);
        setError({ title: 'Inspiration Failed', message: 'Our AI designer is taking a break. Please try again in a moment.' });
    } finally {
        setIsInspiring(false);
    }
  }, [originalImage, originalImageBase64, isInspiring]);

  const handleEnhanceRequest = useCallback(async () => {
    if (!stagedResult?.image) {
      setError({ title: 'No Staged Image', message: 'There is no staged image to enhance.' });
      return;
    }

    setIsLoading(true);
    setError(null);
    
    try {
      const enhancePrompt = "Enhance the image quality, making it higher resolution with sharper details. Do not change the content, style, furniture, or layout of the room. Simply improve the visual fidelity of the existing image.";
      
      const mimeTypeMatch = stagedResult.image.match(/data:(.*);base64,/);
      const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : 'image/png';
      
      const result = await stageImageWithGemini(stagedResult.image, mimeType, enhancePrompt);
      setStagedResult(result);
    } catch (err) {
      console.error(err);
      setError({ title: 'Enhancement Failed', message: 'Our AI engine encountered an issue while enhancing the image. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  }, [stagedResult]);

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-800">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {!originalImageBase64 ? (
          <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="p-4 sm:p-8">
              <h2 className="text-2xl font-bold text-gray-700 mb-2">Virtual Staging Studio</h2>
              <p className="text-gray-500 mb-6">Upload a room photo, describe your vision, and let our AI bring it to life.</p>
              <ImageUploader onImageUpload={handleImageUpload} isLoading={isValidatingImage} uploadError={uploadError}/>
            </div>
          </div>
        ) : (
          <div className={`transition-opacity duration-500 ease-in-out ${isStagingViewVisible ? 'opacity-100' : 'opacity-0'}`}>
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
              {/* --- Left Column (Sticky Controls) --- */}
              <div className="lg:col-span-2 h-full">
                <div className="sticky top-8 bg-white rounded-2xl shadow-lg p-8">
                  <h2 className="text-2xl font-bold text-gray-700 mb-2">Staging Controls</h2>
                  <p className="text-gray-500 mb-6">Use the tools below to transform your image.</p>
                  <PromptControls 
                    onStageRequest={handleStageRequest} 
                    isLoading={isLoading} 
                    promptHistory={promptHistory}
                    onInspireMe={handleInspireMe}
                    isInspiring={isInspiring}
                    inspirations={inspirations}
                  />
                </div>
              </div>

              {/* --- Right Column (Image Display) --- */}
              <div className="lg:col-span-3">
                <div className="bg-white rounded-2xl shadow-lg overflow-hidden p-4 md:p-8 space-y-6">
                  {error && (
                    <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded" role="alert">
                      <p className="font-bold">{error.title}</p>
                      <p>{error.message}</p>
                    </div>
                  )}
                  {isLoading && (
                    <div className="flex flex-col items-center justify-center p-8 bg-gray-100 rounded-lg">
                        <Loader />
                        <p className="mt-4 text-lg font-semibold text-blue-700 animate-pulse">{loadingMessage}</p>
                        <p className="text-gray-500 mt-2">Our AI is re-imagining your space.</p>
                    </div>
                  )}
                  <ResultViewer 
                    originalImage={originalImageBase64} 
                    stagedResult={stagedResult} 
                    onReset={handleReset}
                    onRefine={handleRefineRequest}
                    onRedo={handleRedo}
                    onEnhance={handleEnhanceRequest}
                    isLoading={isLoading}
                    promptHistory={promptHistory}
                  />
                </div>
              </div>
            </div>
          </div>
        )}
        <footer className="text-center mt-8 text-gray-400 text-sm">
          <p>Powered by RealMarketPulse. Images are AI-generated.</p>
        </footer>
      </main>
    </div>
  );
};

export default StagingDashboard;
