import { GoogleGenAI, Modality, GenerateContentResponse, Type } from "@google/genai";
import { StagedResult, StyleTemplate } from '../types';

const MODEL_NAME = 'gemini-2.5-flash-image-preview';
const FAST_MODEL = 'gemini-2.5-flash';
const IMAGE_GEN_MODEL = 'imagen-4.0-generate-001';

function getApiKey(): string {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new Error('API_KEY environment variable not set.');
    }
    return apiKey;
}

const ai = new GoogleGenAI({ apiKey: getApiKey() });

export const isImageSafeForStaging = async (imageBase64: string, mimeType: string): Promise<boolean> => {
    if (!imageBase64.startsWith('data:')) {
        throw new Error('Invalid base64 string. Must be a data URL.');
    }
    const base64Data = imageBase64.split(',')[1];

    try {
        const response = await ai.models.generateContent({
            model: FAST_MODEL,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Data,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: "Analyze the image. Does it contain nudity, weapons, or is it primarily a headshot/portrait of a person? Answer with only 'yes' if it contains any of these, or 'no' if it is safe for a general audience and suitable for a property staging application.",
                    },
                ],
            },
        });

        const resultText = response.text.trim().toLowerCase();
        // The prompt asks to return 'no' if it is safe.
        return resultText.includes('no');
    } catch (error) {
        console.error("Error during image validation:", error);
        // Fail safely - if validation fails, assume it's not a valid image.
        return false;
    }
};

export const isPromptSafe = async (prompt: string): Promise<boolean> => {
    if (!prompt.trim()) {
        return true; // An empty prompt is safe.
    }
    try {
        const response = await ai.models.generateContent({
            model: FAST_MODEL,
            contents: prompt,
            config: {
                systemInstruction: "You are a content moderator. Analyze the user's prompt. If it contains any vulgarity, profanity, hate speech, explicit content, or other inappropriate material, respond with only the word 'unsafe'. Otherwise, respond with only the word 'safe'.",
            }
        });
        
        const resultText = response.text.trim().toLowerCase();
        return resultText.includes('safe');
    } catch (error) {
        console.error("Error during prompt validation:", error);
        // Fail safely - if validation fails, assume it's unsafe.
        return false;
    }
};


export const stageImageWithGemini = async (imageBase64: string, mimeType: string, prompt: string): Promise<StagedResult> => {
    if (!imageBase64.startsWith('data:')) {
        throw new Error('Invalid base64 string. Must be a data URL.');
    }

    const base64Data = imageBase64.split(',')[1];
    if (!base64Data) {
        throw new Error('Could not extract base64 data from string.');
    }

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: MODEL_NAME,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Data,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: prompt,
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });
        
        let newImageBase64: string | null = null;
        let responseText = "AI analysis complete.";

        if (response.candidates && response.candidates[0] && response.candidates[0].content && response.candidates[0].content.parts) {
            for (const part of response.candidates[0].content.parts) {
                if (part.inlineData) {
                    newImageBase64 = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
                } else if (part.text) {
                    responseText = part.text;
                }
            }
        }

        if (!newImageBase64) {
            throw new Error("The AI service did not return an image. This may be due to a safety policy violation or an invalid prompt.");
        }

        return {
            image: newImageBase64,
            text: responseText,
        };
    } catch (error) {
        console.error("Error calling the AI image generation service:", error);
        throw new Error("Failed to stage image with the AI service.");
    }
};

export const getDesignInspirations = async (imageBase64: string, mimeType: string): Promise<StyleTemplate[]> => {
    if (!imageBase64.startsWith('data:')) {
        throw new Error('Invalid base64 string. Must be a data URL.');
    }
    const base64Data = imageBase64.split(',')[1];

    try {
        const response = await ai.models.generateContent({
            model: FAST_MODEL,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Data,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: "Analyze this room and suggest 3-4 creative interior design styles that would suit the space. Provide a name and a detailed prompt for each.",
                    },
                ],
            },
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            name: {
                                type: Type.STRING,
                                description: 'A short, catchy name for the design style (e.g., "Modern Minimalist", "Boho Chic").',
                            },
                            prompt: {
                                type: Type.STRING,
                                description: 'A detailed prompt that can be used to generate the new image. It should describe furniture, colors, and decor for the suggested style, tailored to the room in the image.',
                            },
                        },
                        required: ['name', 'prompt'],
                    },
                },
                systemInstruction: "You are an expert interior designer. Analyze the user's image of a room and provide 3-4 distinct and creative design style suggestions that would suit the space. For each suggestion, provide a name for the style and a detailed descriptive prompt that another AI can use to virtually stage the room with that style.",
            },
        });

        const jsonStr = response.text.trim();
        const inspirations: StyleTemplate[] = JSON.parse(jsonStr);
        
        if (!Array.isArray(inspirations) || inspirations.some(item => typeof item.name !== 'string' || typeof item.prompt !== 'string')) {
            throw new Error("Invalid JSON structure received from AI.");
        }

        return inspirations;
    } catch (error) {
        console.error("Error during design inspiration generation:", error);
        throw new Error("Failed to get design inspirations from the AI service.");
    }
};

export const generateHeroImage = async (): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: IMAGE_GEN_MODEL,
            prompt: 'A photorealistic image showing a living room that seamlessly transitions from a beautifully staged modern interior on the left to an empty, neutral room on the right, with soft lighting. Aspect ratio 16:9.',
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '16:9',
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
            return base64ImageBytes;
        } else {
            throw new Error("The AI service did not return an image for the hero section.");
        }
    } catch (error) {
        console.error("Error calling the AI image generation service for hero image:", error);
        throw new Error("Failed to generate hero image with the AI service.");
    }
};
