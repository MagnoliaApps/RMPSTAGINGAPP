// FIX: Removed duplicate CrownIcon component declaration to resolve redeclaration error.
import React from 'react';

// SVG Credit: Heroicons (MIT License) - simplified and combined crown shape
export const CrownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    {...props}>
    <path d="M19.467 5.347L18 3.88l-4.533 4.533a1.5 1.5 0 01-2.121-.133L6 3.88l-1.467 1.467L2 7.5l2.533.633L6 13.5l6-2.25 6 2.25 1.467-5.367L22 7.5l-2.533-2.153zM12 13.25l-4.5 1.687V21h9v-6.063L12 13.25z"/>
  </svg>
);
