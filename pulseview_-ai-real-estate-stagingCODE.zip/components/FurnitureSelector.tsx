import React from 'react';

interface FurnitureSelectorProps {
  onSelectItem: (promptFragment: string) => void;
}

const FURNITURE_LIBRARY = {
  Sofas: [
    { name: 'Grey Sofa', promptFragment: 'Add a modern grey sofa' },
    { name: 'Leather Couch', promptFragment: 'Add a brown leather couch' },
    { name: 'Sectional', promptFragment: 'Add a comfortable light-colored sectional sofa' },
  ],
  Chairs: [
    { name: 'Armchair', promptFragment: 'Add a stylish armchair in a corner' },
    { name: 'Accent Chair', promptFragment: 'Add a colorful accent chair to the scene' },
    { name: 'Eames Chair', promptFragment: 'Add a classic Eames lounge chair' },
  ],
  Tables: [
    { name: 'Coffee Table', promptFragment: 'Add a wooden coffee table in the center of the room' },
    { name: 'Side Table', promptFragment: 'Add a small side table next to the sofa' },
    { name: 'Dining Table', promptFragment: 'Add a dining table with chairs' },
  ],
  Lamps: [
    { name: 'Floor Lamp', promptFragment: 'Add a tall arc floor lamp for lighting' },
    { name: 'Table Lamp', promptFragment: 'Add a decorative table lamp on a surface' },
    { name: 'Pendant Light', promptFragment: 'Add a modern pendant light hanging from the ceiling' },
  ],
  Decor: [
    { name: 'Wall Art', promptFragment: 'Add some modern wall art' },
    { name: 'Plants', promptFragment: 'Add a few potted plants to liven up the space' },
  ],
};

export const FurnitureSelector: React.FC<FurnitureSelectorProps> = ({ onSelectItem }) => {
  return (
    <div className="space-y-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
      {Object.entries(FURNITURE_LIBRARY).map(([category, items]) => (
        <div key={category}>
          <h4 className="font-semibold text-gray-600 mb-2">{category}</h4>
          <div className="flex flex-wrap gap-2">
            {items.map((item) => (
              <button
                key={item.name}
                onClick={() => onSelectItem(item.promptFragment)}
                className="px-3 py-1.5 text-sm font-medium text-green-800 bg-green-100 rounded-full hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors"
                aria-label={`Add ${item.name}`}
              >
                + {item.name}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};