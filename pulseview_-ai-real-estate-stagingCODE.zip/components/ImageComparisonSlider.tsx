import React, { useState, useRef, useCallback } from 'react';
import { ZoomInIcon } from './icons/ZoomInIcon';

interface ImageComparisonSliderProps {
  beforeImage: string;
  afterImage: string;
  onZoomBefore: () => void;
  onZoomAfter: () => void;
}

export const ImageComparisonSlider: React.FC<ImageComparisonSliderProps> = ({ beforeImage, afterImage, onZoomBefore, onZoomAfter }) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    const percent = (x / rect.width) * 100;
    setSliderPosition(percent);
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    e.preventDefault();
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;
    handleMove(e.clientX);
  };
  
  const handleTouchStart = (e: React.TouchEvent) => {
    isDragging.current = true;
    e.preventDefault();
    handleMove(e.touches[0].clientX);
  };
  
  const handleTouchMove = (e: React.TouchEvent) => {
      if (!isDragging.current) return;
      handleMove(e.touches[0].clientX);
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-video select-none overflow-hidden rounded-lg shadow-inner bg-gray-100"
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onMouseMove={handleMouseMove}
      onTouchEnd={handleMouseUp}
      onTouchCancel={handleMouseUp}
      onTouchMove={handleTouchMove}
    >
      <img src={beforeImage} alt="Before" className="absolute top-0 left-0 w-full h-full object-contain pointer-events-none" />
      <div
        className="absolute top-0 left-0 w-full h-full object-contain overflow-hidden pointer-events-none"
        style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
      >
        <img src={afterImage} alt="After" className="absolute top-0 left-0 w-full h-full object-contain" />
      </div>
      <div
        className="absolute top-0 h-full w-1 bg-white/70 z-10 cursor-ew-resize"
        style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
      >
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 left-1/2 w-10 h-10 rounded-full bg-white/90 shadow-md flex items-center justify-center backdrop-blur-sm">
          <svg className="w-6 h-6 text-gray-700 rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 9l4-4 4 4m0 6l-4 4-4-4"></path></svg>
        </div>
      </div>
      <div className="absolute top-2 left-2 flex items-center gap-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded pointer-events-none">
        <span>Before</span>
        <button
          onClick={(e) => { e.stopPropagation(); onZoomBefore(); }}
          className="p-1 rounded-full bg-white/20 hover:bg-white/40 pointer-events-auto focus:outline-none focus:ring-2 focus:ring-white"
          aria-label="Zoom in on before image"
        >
          <ZoomInIcon className="w-4 h-4 text-white" />
        </button>
      </div>
      <div className="absolute top-2 right-2 flex items-center gap-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded pointer-events-none">
        <span>After (AI)</span>
         <button
          onClick={(e) => { e.stopPropagation(); onZoomAfter(); }}
          className="p-1 rounded-full bg-white/20 hover:bg-white/40 pointer-events-auto focus:outline-none focus:ring-2 focus:ring-white"
          aria-label="Zoom in on after image"
        >
          <ZoomInIcon className="w-4 h-4 text-white" />
        </button>
      </div>
    </div>
  );
};
