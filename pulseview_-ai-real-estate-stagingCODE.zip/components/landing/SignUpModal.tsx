import React, { useEffect, useCallback } from 'react';
import { SparklesIcon } from '../icons/SparklesIcon';

interface SignUpModalProps {
  imageUrl: string;
  onClose: () => void;
  onSignUp: () => void;
}

export const SignUpModal: React.FC<SignUpModalProps> = ({ imageUrl, onClose, onSignUp }) => {
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    }
  }, [onClose]);

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [handleKeyDown]);

  const handleSignUpClick = () => {
    onSignUp();
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="signup-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 backdrop-blur-sm"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-2xl shadow-xl w-full max-w-md m-4 transform transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-8 text-center">
            <div className="w-24 h-24 mx-auto mb-6 rounded-lg overflow-hidden ring-4 ring-blue-200 ring-offset-2">
                <img src={imageUrl} alt="Uploaded preview" className="w-full h-full object-cover" />
            </div>
            <SparklesIcon className="w-12 h-12 text-blue-500 mx-auto mb-4" />
            <h2 id="signup-modal-title" className="text-2xl font-bold text-gray-900">Unlock Your Design</h2>
            <p className="mt-2 text-gray-600">
                Your image is ready to be transformed! Create a free account to see your AI-staged photo and access all features.
            </p>
            <div className="mt-8 flex flex-col space-y-3">
                <button
                    onClick={handleSignUpClick}
                    className="w-full px-6 py-3 text-base font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all transform hover:scale-105"
                >
                    Create Free Account
                </button>
                <button
                    onClick={onClose}
                    className="w-full px-6 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 transition-colors"
                >
                    Maybe Later
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
