
import React, { useState, useEffect, useCallback } from 'react';
import { applyWatermark } from '../services/watermarkService';
import { DownloadIcon } from './icons/DownloadIcon';
import { CrownIcon } from './icons/CrownIcon';
import { Loader } from './Loader';

interface DownloadModalProps {
  imageUrl: string;
  onClose: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ imageUrl, onClose }) => {
  const [watermarkedImage, setWatermarkedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const generateWatermark = async () => {
      setIsLoading(true);
      try {
        const newImage = await applyWatermark(imageUrl);
        setWatermarkedImage(newImage);
      } catch (error) {
        console.error("Failed to apply watermark", error);
        // Fallback to the original image if watermarking fails
        setWatermarkedImage(imageUrl);
      } finally {
        setIsLoading(false);
      }
    };
    generateWatermark();
  }, [imageUrl]);

  const handleDownload = () => {
    if (!watermarkedImage) return;

    const link = document.createElement('a');
    link.href = watermarkedImage;
    link.download = `staged-image-watermarked-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    }
  }, [onClose]);

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [handleKeyDown]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="download-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-xl w-full max-w-lg m-4 transform transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-8 text-center">
          <h2 id="download-modal-title" className="text-2xl font-bold text-gray-900">Download Your Staged Image</h2>
          <p className="mt-2 text-gray-600">
            Your image is ready! Free downloads include a small watermark as a thank you.
          </p>
          <div className="my-6 aspect-video bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden ring-1 ring-gray-200">
            {isLoading ? (
              <div className="flex flex-col items-center">
                <Loader />
                <p className="text-sm text-gray-500 mt-2">Applying watermark...</p>
              </div>
            ) : (
              <img src={watermarkedImage || ''} alt="Staged with watermark" className="w-full h-full object-contain" />
            )}
          </div>
          <div className="mt-8 flex flex-col space-y-3">
            <button
              onClick={handleDownload}
              disabled={isLoading}
              className="w-full inline-flex items-center justify-center px-6 py-3 text-base font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all transform hover:scale-105"
            >
              <DownloadIcon className="w-5 h-5 mr-2" />
              Download with Watermark
            </button>
            <button
              disabled // Feature coming soon
              className="w-full inline-flex items-center justify-center px-6 py-3 text-base font-medium text-purple-700 bg-purple-100 border border-transparent rounded-md shadow-md hover:bg-purple-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-gray-200 disabled:cursor-not-allowed disabled:text-gray-500 transition-all transform hover:scale-105"
            >
              <CrownIcon className="w-5 h-5 mr-2" />
              Upgrade to Pro: Download in HD without Watermark
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
