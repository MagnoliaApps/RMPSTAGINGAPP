import React, { useState } from 'react';
import { FurnitureSelector } from './FurnitureSelector';
import { PromptHistory } from './PromptHistory';
import { StyleTemplate } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';

interface PromptControlsProps {
  onStageRequest: (prompt: string, negativePrompt: string) => void;
  isLoading: boolean;
  promptHistory: string[];
  onInspireMe: () => void;
  isInspiring: boolean;
  inspirations: StyleTemplate[];
}

const ROOM_TYPES = ["Living Room", "Bedroom", "Kitchen", "Dining Room", "Home Office", "Bathroom"];

const QUICK_STAGE_TEMPLATES: StyleTemplate[] = [
  { name: "Modern Minimalist", prompt: "Stage this room with modern minimalist furniture. Use a neutral color palette with clean lines, a simple main furniture piece (like a sofa or bed), a sleek coffee or side table, and minimal decor." },
  { name: "Boho Chic", prompt: "Transform this room into a boho chic paradise. Add comfortable furniture with lots of pillows and throws, macrame wall hangings, many potted plants, and a vintage-style rug." },
  { name: "Coastal Living", prompt: "Give this room a coastal living feel. Use light and airy colors like white, beige, and light blue. Add comfortable, light-colored furniture (like a slipcovered sofa or a light wood bed frame), wicker or rattan accents, and nautical-themed decor." },
  { name: "Scandinavian", prompt: "Apply a Scandinavian design to this room. Focus on simplicity, functionality, and natural materials. Add light-colored furniture, a simple wooden table, and hygge elements like candles and cozy blankets." },
  { name: "Mid-Century Modern", prompt: "Stage this room with Mid-Century Modern furniture. Include a teak wood credenza or sideboard, a primary seating piece with tapered legs, and a sunburst mirror on the wall." },
  { name: "Japandi", prompt: "Create a Japandi style interior, blending Japanese minimalism with Scandinavian functionality. Use natural wood tones, clean lines, neutral colors, and focus on craftsmanship, tranquility, and functional furniture." },
  { name: "Farmhouse", prompt: "Create a modern farmhouse look in this room. Use a mix of rustic and refined elements, like comfortable linen-upholstered seating, a distressed wood coffee or console table, and some vintage-inspired accessories. The color palette should be warm and inviting." },
  { name: "Industrial", prompt: "Give this space an industrial loft vibe. Incorporate materials like exposed brick, metal, and raw wood. Add furniture with clean lines and a utilitarian feel, like a leather sofa or a metal-frame bed, and factory-style lighting fixtures." },
  { name: "Art Deco", prompt: "Style this room with an Art Deco theme. Use bold geometric patterns, rich colors like navy and gold, and luxurious materials like velvet and brass. Add a statement furniture piece and glamorous, stylized decor." },
  { name: "Maximalist", prompt: "Embrace a maximalist design. Fill the space with a rich variety of patterns, colors, and textures. Include bold wallpaper, a gallery wall of art, and eclectic, ornate furniture." },
  { name: "Tropical", prompt: "Create a tropical oasis. Use rattan furniture, large leafy plants like palms and monsteras, and a bright color palette with hints of turquoise and coral." },
  { name: "Victorian", prompt: "Evoke a Victorian era feel with ornate, dark wood furniture, rich velvet upholstery in deep jewel tones, a decorative fireplace mantle, and elaborate wallpaper." },
];

const PROMPT_PLACEHOLDER = `Describe the changes you want to see. Be specific for the best results!

You can ask to:
- ADD items: "Add a large Persian rug under the coffee table."
- REPLACE items: "Replace the armchair with a modern leather recliner."
- REMOVE items: "Remove the coffee table from the scene."
- CHANGE styles: "Change the wall color to a light sage green."

Combine instructions for a complete vision!
e.g., "Add a velvet blue armchair and a brass floor lamp to the modern minimalist living room."`;


export const PromptControls: React.FC<PromptControlsProps> = ({ 
  onStageRequest, 
  isLoading, 
  promptHistory,
  onInspireMe,
  isInspiring,
  inspirations
}) => {
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [selectedRoom, setSelectedRoom] = useState<string | null>(null);

  const handleQuickStageClick = (templatePrompt: string) => {
    let finalPrompt = templatePrompt;
    if (selectedRoom) {
      // Replace generic "room" or "space" with specific room type for better context.
      finalPrompt = templatePrompt.replace(/this room|this space/gi, `this ${selectedRoom.toLowerCase()}`);
    }
    setPrompt(finalPrompt);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let constructedPrompt = prompt;
    if (selectedRoom) {
      // Add context if it's not already there. This is a fallback for manually typed prompts.
      const hasRoomContext = new RegExp(ROOM_TYPES.join('|'), 'i').test(constructedPrompt);
      if (!hasRoomContext) {
        constructedPrompt = `For this ${selectedRoom.toLowerCase()}, ${constructedPrompt}`;
      }
    }

    if (constructedPrompt.trim() || negativePrompt.trim()) {
        onStageRequest(constructedPrompt, negativePrompt);
    }
  }

  const handleFurnitureSelect = (promptFragment: string) => {
    setPrompt(prev => {
      if (!prev.trim()) return promptFragment;
      // Add a period if the previous prompt doesn't end with one.
      const separator = /[.!?]$/.test(prev.trim()) ? ' ' : '. ';
      return `${prev}${separator}${promptFragment}`;
    });
  };

  return (
    <div className="space-y-6">
       <div>
        <h3 className="text-lg font-semibold text-gray-700 mb-2">1. Select Room Type (Optional)</h3>
        <p className="text-sm text-gray-500 mb-4">This helps the AI understand the context of the space.</p>
        <div className="flex flex-wrap gap-2">
          {ROOM_TYPES.map((room) => (
            <button
              key={room}
              type="button"
              onClick={() => setSelectedRoom(room === selectedRoom ? null : room)}
              disabled={isLoading}
              className={`px-4 py-2 text-sm font-medium rounded-full transition-all duration-200 ${
                selectedRoom === room
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-blue-100 text-blue-700 hover:bg-blue-200 hover:shadow'
              } disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed`}
            >
              {room}
            </button>
          ))}
        </div>
      </div>
       <div>
        <h3 className="text-lg font-semibold text-gray-700 mb-2">Need an Idea?</h3>
        <p className="text-sm text-gray-500 mb-4">Let our AI designer suggest styles tailored for your room.</p>
        <button
          type="button"
          onClick={onInspireMe}
          disabled={isLoading || isInspiring}
          className="w-full flex items-center justify-center px-6 py-3 text-base font-medium text-white bg-purple-600 border border-transparent rounded-md shadow-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg active:translate-y-0"
        >
          {isInspiring ? (
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : (
            <SparklesIcon className="w-5 h-5 mr-2" />
          )}
          {isInspiring ? 'Generating Ideas...' : 'Inspire Me!'}
        </button>
      </div>
      <div>
        <h3 className="text-lg font-semibold text-gray-700 mb-2">2. Choose a Style (Quick Stage)</h3>
        <p className="text-sm text-gray-500 mb-4">Click to add a style description to your prompt below.</p>
        
        {inspirations.length > 0 && (
          <div className="mb-6 p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <h4 className="font-semibold text-purple-800 mb-3">✨ AI Suggestions for Your Room</h4>
            <div className="flex flex-wrap gap-2">
              {inspirations.map((template) => (
                <button
                  key={template.name}
                  type="button"
                  onClick={() => handleQuickStageClick(template.prompt)}
                  disabled={isLoading}
                  className="px-4 py-2 text-sm font-medium text-purple-700 bg-purple-200 rounded-full hover:bg-purple-300 disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-200 hover:shadow-sm"
                >
                  {template.name}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          {QUICK_STAGE_TEMPLATES.map((template) => (
            <button
              key={template.name}
              type="button"
              onClick={() => handleQuickStageClick(template.prompt)}
              disabled={isLoading}
              className="px-4 py-2 text-sm font-medium text-blue-700 bg-blue-100 rounded-full hover:bg-blue-200 disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-200 hover:shadow-sm"
            >
              {template.name}
            </button>
          ))}
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">3. Describe Your Vision</h3>
          <p className="text-sm text-gray-500 mb-4">Combine styles, add furniture, or write your own prompt from scratch.</p>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={PROMPT_PLACEHOLDER}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow"
            rows={5}
            disabled={isLoading}
            aria-label="Staging prompt"
          />
          <PromptHistory history={promptHistory} onSelect={setPrompt} isLoading={isLoading} />
        </div>
        
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Or, Add Specific Furniture</h3>
          <FurnitureSelector onSelectItem={handleFurnitureSelect} />
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">4. Exclude Items (Negative Prompt)</h3>
          <p className="text-sm text-gray-500 mb-4">Tell the AI what you <span className="font-bold">don't</span> want to see. This helps avoid unwanted objects.</p>
          <textarea
            value={negativePrompt}
            onChange={(e) => setNegativePrompt(e.target.value)}
            placeholder='e.g., "clutter", "remove the paintings on the wall", "no red colors"'
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-400 focus:border-red-400 transition-shadow"
            rows={2}
            disabled={isLoading}
            aria-label="Negative prompt for items to exclude"
          />
        </div>
        
        <button
          type="submit"
          disabled={isLoading || (!prompt.trim() && !negativePrompt.trim())}
          className="w-full flex items-center justify-center px-6 py-4 text-lg font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg active:translate-y-0"
        >
          {isLoading ? 'Staging...' : 'Stage It!'}
        </button>
      </form>
    </div>
  );
};