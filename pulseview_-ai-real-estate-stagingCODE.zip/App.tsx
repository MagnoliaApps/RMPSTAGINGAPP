import React, { useState } from 'react';
import LandingPage from './pages/LandingPage';
import StagingDashboard from './pages/StagingDashboard';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleSignUp = () => {
    setIsAuthenticated(true);
  };
  
  return (
    <>
      {isAuthenticated ? <StagingDashboard /> : <LandingPage onSignUp={handleSignUp} />}
    </>
  );
};

export default App;
